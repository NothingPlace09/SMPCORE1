package me.nothing.smpcore.systems.chat;

import me.nothing.smpcore.utils.Rich;
import net.kyori.adventure.text.Component;

/** Testo dei config della chat: &c, &#RRGGBB, #RRGGBB, <#RRGGBB>, § e tag MiniMessage (gradient, shadow, color...). */
public class ColorUtil {
   public static String color(String message) {
      return message == null ? "" : Rich.toLegacy(message);
   }

   public static Component colorComponent(String message) {
      return message == null ? Component.empty() : Rich.parseTrusted(message);
   }
}
