package me.nothing.smpcore.systems.clearlag;

import java.util.Locale;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

final class ClearLagPlaceholders extends PlaceholderExpansion {
   private final ClearLagPlugin plugin;

   private ClearLagPlaceholders(ClearLagPlugin clearLagPlugin) {
      this.plugin = clearLagPlugin;
   }

   private static ClearLagPlaceholders active;

   static synchronized boolean register(ClearLagPlugin clearLagPlugin) {
      dropActive();
      ClearLagPlaceholders expansion = new ClearLagPlaceholders(clearLagPlugin);
      boolean ok = expansion.register();
      if (ok) {
         active = expansion;
      }
      return ok;
   }

   static synchronized void dropActive() {
      if (active != null) {
         try {
            active.unregister();
         } catch (Throwable ignored) {
         }
         active = null;
      }
   }

   public String getIdentifier() {
      return "smpcoreclearlag";
   }

   public String getAuthor() {
      return "nothing";
   }

   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onRequest(OfflinePlayer offlinePlayer, String str) {
      long l = this.plugin.secondsToNextSweep();
      switch (str.toLowerCase(Locale.ROOT)) {
         case "next_seconds" -> {
            return String.valueOf(l);
         }
         case "next_minutes" -> {
            return String.valueOf((l + 59L) / 60L);
         }
         case "next" -> {
            return this.alsText(l);
         }
         case "interval" -> {
            return String.valueOf(this.plugin.intervalSeconds());
         }
         case "last_removed" -> {
            return String.valueOf(this.plugin.lastRemoved());
         }
         case "worlds" -> {
            return String.valueOf(this.plugin.worldCount());
         }
         default -> {
            return null;
         }
      }
   }

   private String alsText(long l) {
      String str = this.plugin.config().yaml().getString("placeholders.time-format", "%m%m %s%s");
      return str == null ? "" : str.replace("%total%", String.valueOf(l)).replace("%m%", String.valueOf(l / 60L)).replace("%s%", String.format("%02d", l % 60L));
   }
}
