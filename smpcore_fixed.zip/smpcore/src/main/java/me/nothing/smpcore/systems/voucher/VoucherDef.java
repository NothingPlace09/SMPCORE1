package me.nothing.smpcore.systems.voucher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.item.Items;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class VoucherDef {
   private final String id;
   private final boolean enabled;
   private final String displayName;
   private final String permission;
   private final int maxPerPlayer;
   private final long cooldownMillis;
   private final long lifetimeMillis;
   private final Boolean confirm;
   private final ItemStack captured;
   private final ConfigurationSection itemSection;
   private final String name;
   private final List<String> lore;
   private final List<ItemStack> rewardItems;
   private final double money;
   private final List<String> commands;
   private final List<String> messages;
   private final String broadcast;

   private VoucherDef(String str, boolean flag, String str2, String str3, int i, long l, long l2, Boolean confirmVal, ItemStack itemStack, ConfigurationSection configurationSection, String str4, List<String> list, List<ItemStack> list2, double d, List<String> list3, List<String> list4, String str5) {
      this.id = str;
      this.enabled = flag;
      this.displayName = str2;
      this.permission = str3;
      this.maxPerPlayer = i;
      this.cooldownMillis = l;
      this.lifetimeMillis = l2;
      this.confirm = confirmVal;
      this.captured = itemStack;
      this.itemSection = configurationSection;
      this.name = str4;
      this.lore = list;
      this.rewardItems = list2;
      this.money = d;
      this.commands = list3;
      this.messages = list4;
      this.broadcast = str5;
   }

   public static VoucherDef load(ConfigurationSection section, String id, Logger logger) {
      if (section == null) {
         return null;
      } else {
         ItemStack itemStack = null;
         String itemData = section.getString("item-data", "");
         if (itemData != null && !itemData.isEmpty()) {
            itemStack = ItemCodec.decode(itemData);
            if (itemStack == null) {
               logger.warning("Voucher '" + id + "': item-data could not be read. The line is left untouched so it can be repaired; the `item:` section is used instead.");
            }
         }

         ConfigurationSection itemSec = section.getConfigurationSection("item");
         if (itemStack == null && itemSec == null) {
            logger.warning("Voucher '" + id + "' has neither `item:` nor `item-data:` and cannot be shown to anybody. Skipped.");
            return null;
         } else {
            ConfigurationSection configurationSection2 = section.getConfigurationSection("rewards");
            List list = configurationSection2 == null ? List.of() : Items.readList(configurationSection2, "items", logger);
            double d = configurationSection2 == null ? (double)0.0F : Math.max((double)0.0F, configurationSection2.getDouble("money", (double)0.0F));
            Object obj = configurationSection2 == null ? List.of() : new ArrayList(configurationSection2.getStringList("commands"));
            Object obj2 = configurationSection2 == null ? List.of() : new ArrayList(configurationSection2.getStringList("messages"));
            String str2 = configurationSection2 == null ? "" : configurationSection2.getString("broadcast", "");
            if (list.isEmpty() && d <= (double)0.0F && ((List)obj).isEmpty()) {
               logger.warning("Voucher '" + id + "' hands out nothing: no items, no money, no commands. Redeeming it will only print its messages.");
            }

            Boolean booleanVal = section.isSet("confirm") ? section.getBoolean("confirm") : null;
            return new VoucherDef(id, section.getBoolean("enabled", true), section.getString("display-name", id), section.getString("permission", ""), section.getInt("max-per-player", -1), TimeText.parse(section.getString("cooldown", "")), TimeText.parse(section.getString("lifetime", "")), booleanVal, itemStack, itemSec, section.getString("name", ""), new ArrayList(section.getStringList("lore")), list, d, (List)obj, (List)obj2, str2 == null ? "" : str2);
         }
      }
   }

   public ItemStack build(Map<String, String> map, List<String> list, Logger logger) {
      ItemStack itemStack;
      if (this.captured != null) {
         itemStack = this.captured.clone();
      } else {
         itemStack = Items.read(this.itemSection, logger, map);
      }

      if (itemStack == null) {
         return null;
      } else {
         itemStack.setAmount(1);
         ItemMeta itemMeta = itemStack.getItemMeta();
         if (itemMeta == null) {
            return itemStack;
         } else {
            if (!this.name.isEmpty()) {
               itemMeta.setDisplayName(Text.item(Text.apply(this.name, map)));
            }

            ArrayList arrayList = new ArrayList();
            if (!this.lore.isEmpty()) {
               for(String var8 : Text.apply(this.lore, map)) {
                  arrayList.add(Text.item(var8));
               }
            } else if (itemMeta.hasLore() && itemMeta.getLore() != null) {
               arrayList.addAll(itemMeta.getLore());
            }

            for(String var10 : Text.apply(list, map)) {
               arrayList.add(Text.item(var10));
            }

            if (!arrayList.isEmpty()) {
               itemMeta.setLore(arrayList);
            }

            itemStack.setItemMeta(itemMeta);
            return itemStack;
         }
      }
   }

   public String id() {
      return this.id;
   }

   public boolean enabled() {
      return this.enabled;
   }

   public String displayName() {
      return this.displayName;
   }

   public String plainName() {
      return Text.strip(this.displayName);
   }

   public String permission() {
      return this.permission;
   }

   public int maxPerPlayer() {
      return this.maxPerPlayer;
   }

   public long cooldownMillis() {
      return this.cooldownMillis;
   }

   public long lifetimeMillis() {
      return this.lifetimeMillis;
   }

   public boolean confirm(boolean flag) {
      return this.confirm == null ? flag : this.confirm;
   }

   public List<ItemStack> rewardItems() {
      ArrayList arrayList = new ArrayList(this.rewardItems.size());

      for(ItemStack var3 : this.rewardItems) {
         arrayList.add(var3.clone());
      }

      return arrayList;
   }

   public int neededSlots() {
      int i = 0;

      for(ItemStack var3 : this.rewardItems) {
         int i2 = Math.max(1, var3.getMaxStackSize());
         i += (var3.getAmount() + i2 - 1) / i2;
      }

      return i;
   }

   public double money() {
      return this.money;
   }

   public List<String> commands() {
      return Collections.unmodifiableList(this.commands);
   }

   public List<String> messages() {
      return Collections.unmodifiableList(this.messages);
   }

   public String broadcast() {
      return this.broadcast;
   }

   public Material material() {
      if (this.captured != null) {
         return this.captured.getType();
      } else {
         String str = this.itemSection == null ? "" : this.itemSection.getString("material", "");
         Material material = str.isEmpty() ? null : Material.matchMaterial(str.toUpperCase(Locale.ROOT));
         return material == null ? Material.PAPER : material;
      }
   }
}
