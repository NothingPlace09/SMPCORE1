package me.nothing.smpcore.systems.smpcorelib.gui;

import java.util.ArrayList;
import java.util.List;

public final class LayoutGrid {
   private final char[] slots;
   private final int rows;

   private LayoutGrid(char[] var1, int var2) {
      this.slots = var1;
      this.rows = var2;
   }

   public static LayoutGrid parse(List<String> var0, char var1) {
      Object obj = new ArrayList();

      for(String var4 : var0) {
         if (var4 != null) {
            String str = var4.length() >= 9 ? var4.substring(0, 9) : var4 + String.valueOf(var1).repeat(9 - var4.length());
            ((List)obj).add(str);
         }
      }

      if (((List)obj).isEmpty()) {
         ((List)obj).add(String.valueOf(var1).repeat(9));
      }

      if (((List)obj).size() > 6) {
         obj = ((List)obj).subList(0, 6);
      }

      char[] cArr = new char[((List)obj).size() * 9];

      for(int var7 = 0; var7 < ((List)obj).size(); ++var7) {
         for(int var8 = 0; var8 < 9; ++var8) {
            cArr[var7 * 9 + var8] = ((String)((List)obj).get(var7)).charAt(var8);
         }
      }

      return new LayoutGrid(cArr, ((List)obj).size());
   }

   public int rows() {
      return this.rows;
   }

   public int size() {
      return this.slots.length;
   }

   public char symbolAt(int var1) {
      return var1 >= 0 && var1 < this.slots.length ? this.slots[var1] : '\u0000';
   }

   public List<Integer> slotsOf(char var1) {
      ArrayList arrayList = new ArrayList();

      for(int var3 = 0; var3 < this.slots.length; ++var3) {
         if (this.slots[var3] == var1) {
            arrayList.add(var3);
         }
      }

      return arrayList;
   }
}
