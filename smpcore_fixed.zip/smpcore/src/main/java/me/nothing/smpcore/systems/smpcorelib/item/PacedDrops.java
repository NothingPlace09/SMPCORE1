package me.nothing.smpcore.systems.smpcorelib.item;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class PacedDrops {
   private final Plugin plugin;
   private final Deque<Eintrag> schlange = new ArrayDeque();
   private int proTick;
   private Scheduler.Task aufgabe;

   public PacedDrops(Plugin var1, int var2) {
      this.plugin = var1;
      this.proTick = Math.max(1, var2);
   }

   public void proTick(int var1) {
      this.proTick = Math.max(1, var1);
   }

   public void drop(Location var1, List<ItemStack> var2) {
      if (var1 != null && var1.getWorld() != null && !var2.isEmpty()) {
         synchronized(this.schlange) {
            if (var2.size() <= this.proTick && this.schlange.isEmpty()) {
               for(ItemStack var9 : var2) {
                  this.lege(var1, var9);
               }

            } else {
               for(ItemStack var5 : var2) {
                  this.schlange.add(new Eintrag(var1, var5));
               }

               this.starte();
            }
         }
      }
   }

   private void starte() {
      if (this.aufgabe == null) {
         this.aufgabe = Scheduler.timer(this.plugin, () -> {
            synchronized(this.schlange) {
               for(int var2 = 0; var2 < this.proTick && !this.schlange.isEmpty(); ++var2) {
                  Eintrag eintrag = (Eintrag)this.schlange.poll();
                  this.lege(eintrag.wo(), eintrag.stapel());
               }

               if (this.schlange.isEmpty()) {
                  this.stoppe();
               }

            }
         }, 1L, 1L);
      }
   }

   private void lege(Location var1, ItemStack var2) {
      if (var1.getWorld() != null) {
         Scheduler.atLocation(this.plugin, var1, () -> {
            if (var1.getWorld() != null && var1.getWorld().isChunkLoaded(var1.getBlockX() >> 4, var1.getBlockZ() >> 4)) {
               var1.getWorld().dropItemNaturally(var1, var2);
            }

         });
      }
   }

   public void flush() {
      synchronized(this.schlange) {
         this.stoppe();

         while(!this.schlange.isEmpty()) {
            Eintrag eintrag = (Eintrag)this.schlange.poll();
            if (eintrag.wo().getWorld() != null) {
               eintrag.wo().getWorld().dropItemNaturally(eintrag.wo(), eintrag.stapel());
            }
         }

      }
   }

   private void stoppe() {
      if (this.aufgabe != null) {
         this.aufgabe.cancel();
         this.aufgabe = null;
      }

   }

   private static record Eintrag(Location wo, ItemStack stapel) {
   }
}
