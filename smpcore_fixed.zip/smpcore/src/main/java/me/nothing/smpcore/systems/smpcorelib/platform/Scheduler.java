package me.nothing.smpcore.systems.smpcorelib.platform;

import java.lang.reflect.Method;
import java.util.Objects;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class Scheduler {
   private static final boolean FOLIA = sucheKlasse("io.papermc.paper.threadedregions.RegionizedServer");

   private Scheduler() {
   }

   private static boolean sucheKlasse(String str) {
      try {
         Class.forName(str);
         return true;
      } catch (ClassNotFoundException e) {
         return false;
      }
   }

   private static Plugin real(Plugin plugin) {
      if (plugin instanceof SystemHost && ((SystemHost)plugin).getCore() != null) {
         return ((SystemHost)plugin).getCore();
      }
      return plugin;
   }

   public static boolean folia() {
      return FOLIA;
   }

   public static void global(Plugin plugin, Runnable runnable) {
      plugin = real(plugin);
      if (!FOLIA) {
         Bukkit.getScheduler().runTask(plugin, runnable);
      } else {
         rufe(globalScheduler(), "run", new Class[]{Plugin.class, Consumer.class}, plugin, huelle(runnable));
      }
   }

   public static Task later(Plugin plugin, Runnable runnable, long l) {
      plugin = real(plugin);
      l = Math.max(1L, l);
      if (!FOLIA) {
         return huelle(Bukkit.getScheduler().runTaskLater(plugin, runnable, l));
      } else {
         Object obj = rufe(globalScheduler(), "runDelayed", new Class[]{Plugin.class, Consumer.class, Long.TYPE}, plugin, huelle(runnable), l);
         return foliaTask(obj);
      }
   }

   public static Task timer(Plugin plugin, Runnable runnable, long l, long l2) {
      plugin = real(plugin);
      l = Math.max(1L, l);
      l2 = Math.max(1L, l2);
      if (!FOLIA) {
         return huelle(Bukkit.getScheduler().runTaskTimer(plugin, runnable, l, l2));
      } else {
         Object obj = rufe(globalScheduler(), "runAtFixedRate", new Class[]{Plugin.class, Consumer.class, Long.TYPE, Long.TYPE}, plugin, huelle(runnable), l, l2);
         return foliaTask(obj);
      }
   }

   public static void async(Plugin plugin, Runnable runnable) {
      plugin = real(plugin);
      if (!FOLIA) {
         Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
      } else {
         rufe(asyncScheduler(), "runNow", new Class[]{Plugin.class, Consumer.class}, plugin, huelle(runnable));
      }
   }

   public static void atEntity(Plugin plugin, Entity entity, Runnable runnable) {
      plugin = real(plugin);
      if (!FOLIA) {
         Bukkit.getScheduler().runTask(plugin, runnable);
      } else {
         try {
            Object obj = entity.getClass().getMethod("getScheduler").invoke(entity);
            obj.getClass().getMethod("run", Plugin.class, Consumer.class, Runnable.class).invoke(obj, plugin, huelle(runnable), null);
         } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Folia entity scheduler not reachable", e);
         }
      }
   }

   public static void atLocation(Plugin plugin, Location location, Runnable runnable) {
      plugin = real(plugin);
      if (!FOLIA) {
         Bukkit.getScheduler().runTask(plugin, runnable);
      } else {
         rufe(regionScheduler(), "run", new Class[]{Plugin.class, Location.class, Consumer.class}, plugin, location, huelle(runnable));
      }
   }

   private static Object globalScheduler() {
      return bukkitScheduler("getGlobalRegionScheduler");
   }

   private static Object asyncScheduler() {
      return bukkitScheduler("getAsyncScheduler");
   }

   private static Object regionScheduler() {
      return bukkitScheduler("getRegionScheduler");
   }

   private static Object bukkitScheduler(String str) {
      try {
         return Bukkit.class.getMethod(str).invoke((Object)null);
      } catch (ReflectiveOperationException e) {
         throw new IllegalStateException("Folia scheduler " + str + " not reachable", e);
      }
   }

   private static Object rufe(Object obj, String str, Class<?>[] classArr, Object... objArr) {
      try {
         Method method = obj.getClass().getMethod(str, classArr);
         method.setAccessible(true);
         return method.invoke(obj, objArr);
      } catch (ReflectiveOperationException e) {
         throw new IllegalStateException("Folia scheduler call " + str + " failed", e);
      }
   }

   private static Consumer<Object> huelle(Runnable runnable) {
      return (var1) -> runnable.run();
   }

   private static Task huelle(BukkitTask bukkitTask) {
      Objects.requireNonNull(bukkitTask);
      return bukkitTask::cancel;
   }

   private static Task foliaTask(Object obj) {
      return obj == null ? () -> {
      } : () -> {
         try {
            Method method = obj.getClass().getMethod("cancel");
            method.setAccessible(true);
            method.invoke(obj);
         } catch (ReflectiveOperationException e) {
            Bukkit.getLogger().warning("[SmpCore] Folia-Aufgabe liess sich nicht abbrechen: " + String.valueOf(e));
         }

      };
   }

   public interface Task {
      void cancel();
   }
}
