package me.nothing.smpcore.systems.tab;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.utils.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Tablist, nametag e belowname, configurati dai file della cartella tab/:
 * config.yml (funzioni), groups.yml (prefissi/suffissi per rank), animations.yml (animazioni del footer).
 * Lo scoreboard laterale e' in ScoreboardModule, che legge la sezione "scoreboard" dello stesso config.yml.
 */
public class TabModule implements Module, Listener {
   private static final String BELOW_NAME = "smpcore_bn";
   private static final NamedTextColor[] LEGACY_COLORS = new NamedTextColor[]{NamedTextColor.BLACK, NamedTextColor.DARK_BLUE, NamedTextColor.DARK_GREEN, NamedTextColor.DARK_AQUA, NamedTextColor.DARK_RED, NamedTextColor.DARK_PURPLE, NamedTextColor.GOLD, NamedTextColor.GRAY, NamedTextColor.DARK_GRAY, NamedTextColor.BLUE, NamedTextColor.GREEN, NamedTextColor.AQUA, NamedTextColor.RED, NamedTextColor.LIGHT_PURPLE, NamedTextColor.YELLOW, NamedTextColor.WHITE};

   private static final class BoardState {
      final Map<String, String> entryTeam = new HashMap<>();
      final Map<String, String> teamSig = new HashMap<>();
      final Map<String, String> belowSig = new HashMap<>();
      String belowTitle = "";
   }

   private static final class Info {
      final String name;
      final String teamName;
      final Component prefix;
      final Component suffix;
      final NamedTextColor color;
      final String sig;

      Info(String name, String teamName, Component prefix, Component suffix, NamedTextColor color, String sig) {
         this.name = name;
         this.teamName = teamName;
         this.prefix = prefix;
         this.suffix = suffix;
         this.color = color;
         this.sig = sig;
      }
   }

   private final SmpCore plugin;
   private FileConfiguration cfg;
   private YamlConfiguration groups;
   private final TabAnimations animations = new TabAnimations();
   private int taskId = -1;
   private final List<String> groupOrder = new ArrayList<>();
   private String tieBreaker = "%player%";
   private boolean caseSensitive = true;
   private final Map<UUID, String> lastHeaderFooter = new ConcurrentHashMap<>();
   private final Map<UUID, String> lastListName = new ConcurrentHashMap<>();
   private final Map<Scoreboard, BoardState> states = new WeakHashMap<>();

   public TabModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "tab";
   }

   public void onEnable() {
      this.loadConfig();
      this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
      this.taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, this::refreshAll, 20L, 20L);
      this.refreshAll();
   }

   public void onDisable() {
      if (this.taskId != -1) {
         Bukkit.getScheduler().cancelTask(this.taskId);
      }

      this.taskId = -1;
      Set<Scoreboard> boards = Collections.newSetFromMap(new IdentityHashMap<>());
      boards.addAll(this.states.keySet());
      for(Player p : Bukkit.getOnlinePlayers()) {
         boards.add(p.getScoreboard());
         p.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());

         try {
            p.playerListName((Component)null);
         } catch (Throwable t) {
         }
      }

      for(Scoreboard board : boards) {
         BoardState st = this.states.get(board);
         if (st != null) {
            for(String teamName : new HashSet<>(st.entryTeam.values())) {
               Team team = board.getTeam(teamName);
               if (team != null) {
                  team.unregister();
               }
            }
         }

         Objective obj = board.getObjective(BELOW_NAME);
         if (obj != null) {
            obj.unregister();
         }
      }

      this.states.clear();
      this.lastHeaderFooter.clear();
      this.lastListName.clear();
   }

   public void reload() {
      this.onDisable();
      this.onEnable();
   }

   private Component comp(String text) {
      return TabHeads.apply(text, TextUtil::component);
   }

   private File tabFile(String name) {
      File f = new File(this.plugin.getDataFolder(), "tab/" + name);
      if (!f.exists()) {
         try {
            this.plugin.saveResource("tab/" + name, false);
         } catch (Exception e) {
         }
      }

      return f;
   }

   private void loadConfig() {
      File f = this.tabFile("config.yml");
      this.cfg = f.exists() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
      File gf = this.tabFile("groups.yml");
      this.groups = gf.exists() ? YamlConfiguration.loadConfiguration(gf) : new YamlConfiguration();
      this.animations.load(this.tabFile("animations.yml"));
      TabHeads.configure(this.cfg.getBoolean("tab.disable-shadow-for-heads", true));
      this.groupOrder.clear();
      this.tieBreaker = "%player%";
      this.caseSensitive = this.cfg.getBoolean("tab.nametags.case-sensitive-sorting", true);

      for(String line : this.cfg.getStringList("tab.tablist-name-formatting.sorting-types")) {
         if (line == null) {
            continue;
         }

         String upper = line.toUpperCase(Locale.ROOT);
         if (upper.startsWith("GROUPS:")) {
            for(String g : line.substring(7).split(",")) {
               String t = g.trim().toLowerCase(Locale.ROOT);
               if (!t.isEmpty()) {
                  this.groupOrder.add(t);
               }
            }
         } else if (upper.startsWith("PLACEHOLDER_A_TO_Z:")) {
            this.tieBreaker = line.substring("PLACEHOLDER_A_TO_Z:".length()).trim();
         }
      }

      if (this.groupOrder.isEmpty()) {
         this.groupOrder.add("default");
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent e) {
      Bukkit.getScheduler().runTask(this.plugin, this::refreshAll);
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent e) {
      UUID id = e.getPlayer().getUniqueId();
      this.lastHeaderFooter.remove(id);
      this.lastListName.remove(id);
      Bukkit.getScheduler().runTask(this.plugin, this::refreshAll);
   }

   private void refreshAll() {
      if (this.cfg == null) {
         return;
      }

      List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
      boolean teamsOn = this.cfg.getBoolean("tab.nametags.enabled", true);
      boolean belowOn = this.cfg.getBoolean("tab.belowname.enabled", false);
      Map<String, Info> infos = new LinkedHashMap<>();

      for(Player p : online) {
         try {
            this.applyHeaderFooter(p);
            this.applyListName(p);
            if (teamsOn && !this.isDisabled(this.cfg.getString("tab.tablist-name-formatting.disable-condition", ""), p)) {
               infos.put(p.getName(), this.info(p));
            }
         } catch (Throwable t) {
            this.plugin.getLogger().warning("[tab] could not update " + p.getName() + ": " + t.getMessage());
         }
      }

      Set<Scoreboard> seen = Collections.newSetFromMap(new IdentityHashMap<>());
      for(Player viewer : online) {
         Scoreboard board = viewer.getScoreboard();
         if (board == null || !seen.add(board)) {
            continue;
         }

         try {
            BoardState st = this.states.computeIfAbsent(board, k -> new BoardState());
            this.syncTeams(board, st, teamsOn ? infos : Collections.emptyMap());
            this.syncBelowName(board, st, belowOn, online);
         } catch (Throwable t) {
            this.plugin.getLogger().warning("[tab] scoreboard sync failed: " + t.getMessage());
         }
      }
   }

   // ---- header / footer ----

   private void applyHeaderFooter(Player player) {
      if (!this.cfg.getBoolean("tab.enabled", true)) {
         return;
      }

      String header = this.joinLines(this.cfg.getStringList("tab.header"), player);
      String footer = this.joinLines(this.cfg.getStringList("tab.footer"), player);
      String sig = header + "\u0000" + footer;
      if (!sig.equals(this.lastHeaderFooter.get(player.getUniqueId()))) {
         this.lastHeaderFooter.put(player.getUniqueId(), sig);
         player.sendPlayerListHeaderAndFooter(this.comp(header), this.comp(footer));
      }
   }

   private String joinLines(List<String> lines, Player player) {
      List<String> out = new ArrayList<>();
      for(String line : lines) {
         out.add(this.resolve(player, line));
      }

      return String.join("\n", out);
   }

   private String resolve(Player player, String text) {
      return TabPlaceholders.apply(player, this.animations.apply(text));
   }

   // ---- tablist name ----

   private void applyListName(Player player) {
      if (!this.cfg.getBoolean("tab.tablist-name-formatting.enabled", true)) {
         return;
      }

      if (this.isDisabled(this.cfg.getString("tab.tablist-name-formatting.disable-condition", ""), player)) {
         if (this.lastListName.remove(player.getUniqueId()) != null) {
            player.playerListName((Component)null);
         }

         return;
      }

      ConfigurationSection g = this.groupSection(this.primaryGroup(player));
      String prefix = g == null ? "" : this.resolve(player, g.getString("tabprefix", ""));
      String suffix = g == null ? "" : this.resolve(player, g.getString("tabsuffix", ""));
      String full = prefix + player.getName() + suffix;
      if (!full.equals(this.lastListName.get(player.getUniqueId()))) {
         this.lastListName.put(player.getUniqueId(), full);
         player.playerListName(this.comp(full));
      }
   }

   // ---- groups ----

   private String primaryGroup(Player player) {
      try {
         if (Bukkit.getPluginManager().getPlugin("LuckPerms") != null) {
            User user = LuckPermsProvider.get().getUserManager().getUser(player.getUniqueId());
            if (user != null && user.getPrimaryGroup() != null) {
               return user.getPrimaryGroup().toLowerCase(Locale.ROOT);
            }
         }
      } catch (Throwable t) {
      }

      for(String key : this.groups.getKeys(false)) {
         if (!key.equalsIgnoreCase("_DEFAULT_") && player.hasPermission("group." + key.toLowerCase(Locale.ROOT))) {
            return key.toLowerCase(Locale.ROOT);
         }
      }

      return "default";
   }

   private ConfigurationSection groupSection(String group) {
      if (!group.equalsIgnoreCase("default")) {
         for(String key : this.groups.getKeys(false)) {
            if (key.equalsIgnoreCase(group)) {
               return this.groups.getConfigurationSection(key);
            }
         }
      }

      return this.groups.getConfigurationSection("_DEFAULT_");
   }

   private int groupIndex(String group) {
      int idx = this.groupOrder.indexOf(group.toLowerCase(Locale.ROOT));
      if (idx < 0) {
         idx = this.groupOrder.indexOf("default");
      }

      return idx < 0 ? this.groupOrder.size() : idx;
   }

   // ---- nametag teams ----

   private Info info(Player p) {
      String group = this.primaryGroup(p);
      ConfigurationSection g = this.groupSection(group);
      String prefix = g == null ? "" : this.resolve(p, g.getString("tagprefix", ""));
      String suffix = g == null ? "" : this.resolve(p, g.getString("tagsuffix", ""));
      String tie = this.resolve(p, this.tieBreaker);
      if (!this.caseSensitive) {
         tie = tie.toLowerCase(Locale.ROOT);
      }

      String base = tie.equalsIgnoreCase(p.getName()) ? p.getName() : tie + "~" + p.getName();
      if (!this.caseSensitive) {
         base = base.toLowerCase(Locale.ROOT);
      }

      String teamName = String.format(Locale.ROOT, "%02d", Math.min(this.groupIndex(group), 99)) + base;
      if (teamName.length() > 60) {
         teamName = teamName.substring(0, 60);
      }

      NamedTextColor color = lastLegacyColor(prefix);
      String sig = prefix + "\u0000" + suffix + "\u0000" + (color == null ? "" : color.toString());
      return new Info(p.getName(), teamName, this.comp(prefix), this.comp(suffix), color, sig);
   }

   /** Ultimo codice colore legacy (&0-&f) del prefisso: il nome del giocatore eredita quel colore. */
   private static NamedTextColor lastLegacyColor(String prefix) {
      NamedTextColor found = null;
      for(int i = 0; i + 1 < prefix.length(); ++i) {
         char c = prefix.charAt(i);
         if (c == '&' || c == '§') {
            int idx = Character.digit(prefix.charAt(i + 1), 16);
            if (idx >= 0 && idx < LEGACY_COLORS.length) {
               found = LEGACY_COLORS[idx];
            } else if (prefix.charAt(i + 1) == 'r' || prefix.charAt(i + 1) == 'R') {
               found = null;
            }
         }
      }

      return found;
   }

   private void syncTeams(Scoreboard board, BoardState st, Map<String, Info> infos) {
      boolean collision = this.cfg.getBoolean("tab.nametags.collision", true);
      boolean invisible = this.cfg.getBoolean("tab.nametags.invisible", false);
      boolean friendly = this.cfg.getBoolean("tab.nametags.can-see-friendly-invisibles", false);

      for(Info i : infos.values()) {
         String current = st.entryTeam.get(i.name);
         if (current != null && !current.equals(i.teamName)) {
            Team old = board.getTeam(current);
            if (old != null) {
               old.removeEntry(i.name);
               if (old.getEntries().isEmpty()) {
                  old.unregister();
               }
            }

            st.teamSig.remove(current);
            st.entryTeam.remove(i.name);
         }

         Team team = board.getTeam(i.teamName);
         if (team == null) {
            try {
               team = board.registerNewTeam(i.teamName);
            } catch (IllegalArgumentException e) {
               team = board.getTeam(i.teamName);
            }

            if (team == null) {
               continue;
            }

            st.teamSig.remove(i.teamName);
         }

         String sig = i.sig + "|" + collision + invisible + friendly;
         if (!sig.equals(st.teamSig.get(i.teamName))) {
            team.prefix(i.prefix);
            team.suffix(i.suffix);
            if (i.color != null) {
               team.color(i.color);
            }

            team.setOption(Team.Option.COLLISION_RULE, collision ? Team.OptionStatus.ALWAYS : Team.OptionStatus.NEVER);
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, invisible ? Team.OptionStatus.NEVER : Team.OptionStatus.ALWAYS);
            team.setCanSeeFriendlyInvisibles(friendly);
            st.teamSig.put(i.teamName, sig);
         }

         if (!team.hasEntry(i.name)) {
            team.addEntry(i.name);
         }

         st.entryTeam.put(i.name, i.teamName);
      }

      Iterator<Map.Entry<String, String>> it = st.entryTeam.entrySet().iterator();
      while(it.hasNext()) {
         Map.Entry<String, String> e = it.next();
         if (!infos.containsKey(e.getKey())) {
            Team team = board.getTeam(e.getValue());
            if (team != null) {
               team.removeEntry(e.getKey());
               if (team.getEntries().isEmpty()) {
                  team.unregister();
               }
            }

            st.teamSig.remove(e.getValue());
            it.remove();
         }
      }
   }

   // ---- belowname ----

   private void syncBelowName(Scoreboard board, BoardState st, boolean enabled, List<Player> online) {
      Objective obj = board.getObjective(BELOW_NAME);
      if (!enabled) {
         if (obj != null) {
            obj.unregister();
            st.belowSig.clear();
         }

         return;
      }

      String title = this.cfg.getString("tab.belowname.title", "");
      if (obj == null) {
         obj = board.registerNewObjective(BELOW_NAME, "dummy", this.comp(title));
         obj.setDisplaySlot(DisplaySlot.BELOW_NAME);
         st.belowSig.clear();
         st.belowTitle = title;
      } else if (!title.equals(st.belowTitle)) {
         obj.displayName(this.comp(title));
         st.belowTitle = title;
      }

      String valueTpl = this.cfg.getString("tab.belowname.value", "0");
      String fancyTpl = this.cfg.getString("tab.belowname.fancy-value", "");
      String condition = this.cfg.getString("tab.belowname.disable-condition", "");
      Set<String> names = new HashSet<>();

      for(Player target : online) {
         String name = target.getName();
         names.add(name);
         if (this.isDisabled(condition, target)) {
            if (st.belowSig.remove(name) != null) {
               board.resetScores(name);
            }

            continue;
         }

         int value = 0;
         try {
            value = (int)Double.parseDouble(this.resolve(target, valueTpl).trim());
         } catch (NumberFormatException e) {
         }

         String fancy = this.resolve(target, fancyTpl);
         String sig = value + "\u0000" + fancy;
         if (!sig.equals(st.belowSig.get(name))) {
            Score score = obj.getScore(name);
            score.setScore(value);
            try {
               score.numberFormat(fancy.isEmpty() ? null : NumberFormat.fixed(this.comp(fancy)));
            } catch (Throwable t) {
            }

            st.belowSig.put(name, sig);
         }
      }

      Iterator<String> it = st.belowSig.keySet().iterator();
      while(it.hasNext()) {
         String name = it.next();
         if (!names.contains(name)) {
            board.resetScores(name);
            it.remove();
         }
      }
   }

   // ---- helpers ----

   private boolean isDisabled(String condition, Player player) {
      if (condition != null && !condition.isEmpty()) {
         String world = player.getWorld() != null ? player.getWorld().getName() : "";
         String cond = condition.replace("%world%", world).replace("%player%", player.getName());
         if (!cond.contains("=")) {
            return false;
         } else {
            String[] parts = cond.split("=", 2);
            return parts.length == 2 && parts[0].trim().equalsIgnoreCase(parts[1].trim());
         }
      } else {
         return false;
      }
   }
}
