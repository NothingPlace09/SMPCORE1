package me.nothing.smpcore.systems.invest;

public final class InvestData {
   private double invested;
   private double pending;
   private boolean autoCollect;
   private double extraMax;

   public double invested() {
      return this.invested;
   }

   public void setInvested(double d) {
      this.invested = Math.max((double)0.0F, d);
   }

   public double pending() {
      return this.pending;
   }

   public void setPending(double d) {
      this.pending = Math.max((double)0.0F, d);
   }

   public void addPending(double d) {
      this.setPending(this.pending + d);
   }

   public boolean autoCollect() {
      return this.autoCollect;
   }

   public void setAutoCollect(boolean flag) {
      this.autoCollect = flag;
   }

   public double extraMax() {
      return this.extraMax;
   }

   public void setExtraMax(double d) {
      this.extraMax = Math.max((double)0.0F, d);
   }

   public boolean empty() {
      return this.invested <= (double)0.0F && this.pending <= (double)0.0F && this.extraMax <= (double)0.0F && !this.autoCollect;
   }
}
