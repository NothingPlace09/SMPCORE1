package me.nothing.smpcore.systems.smpcorelib.platform;

import java.lang.reflect.Method;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

public final class Teleports {
   private static final Method ASYNC = sucheAsync();

   private Teleports() {
   }

   private static Method sucheAsync() {
      try {
         return Entity.class.getMethod("teleportAsync", Location.class);
      } catch (NoSuchMethodException e) {
         return null;
      }
   }

   public static boolean async() {
      return ASYNC != null;
   }

   public static void nach(Plugin plugin, Entity entity, Location location, Consumer<Boolean> consumer) {
      if (entity != null && location != null) {
         if (ASYNC == null) {
            melde(consumer, entity.teleport(location));
         } else {
            try {
               Object obj = ASYNC.invoke(entity, location);
               if (obj instanceof CompletableFuture) {
                  CompletableFuture completableFuture = (CompletableFuture)obj;
                  completableFuture.thenAccept((var1x) -> melde(consumer, Boolean.TRUE.equals(var1x)));
               } else {
                  melde(consumer, true);
               }
            } catch (ReflectiveOperationException e) {
               plugin.getLogger().warning("teleportAsync nicht aufrufbar (" + String.valueOf(e) + ") - es wird synchron teleportiert.");

               try {
                  melde(consumer, entity.teleport(location));
               } catch (RuntimeException e2) {
                  plugin.getLogger().warning("Teleport fehlgeschlagen: " + String.valueOf(e2));
                  melde(consumer, false);
               }
            }

         }
      } else {
         melde(consumer, false);
      }
   }

   private static void melde(Consumer<Boolean> consumer, boolean flag) {
      if (consumer != null) {
         consumer.accept(flag);
      }

   }
}
