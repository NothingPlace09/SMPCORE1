package me.nothing.smpcore.systems.tab;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;

/**
 * Teste dei giocatori nel testo, come nel plugin TAB: <head:%player%> (nome o UUID).
 * Usa i componenti "object" di Adventure/Minecraft 1.21.9+ tramite reflection, cosi' il plugin
 * compila anche con l'API 1.21.1 e, su server piu' vecchi, la testa viene semplicemente tolta.
 */
public final class TabHeads {
   private static final Pattern TOKEN = Pattern.compile("<head:([^>]+)>");
   private static final char OPEN = '\uE000';
   private static final char CLOSE = '\uE001';
   private static final Pattern PLACEHOLDER = Pattern.compile("\uE000(\\d+)\uE001");

   private static boolean disableShadow = true;
   private static boolean resolved;
   private static boolean supported;
   private static Method playerHead;
   private static Method builderName;
   private static Method builderId;
   private static Method builderHat;
   private static Method builderBuild;
   private static Method componentObject;
   private static Method componentShadow;
   private static Object shadowNone;

   private TabHeads() {
   }

   public static void configure(boolean disableShadowForHeads) {
      disableShadow = disableShadowForHeads;
   }

   public static boolean supported() {
      resolve();
      return supported;
   }

   private static synchronized void resolve() {
      if (resolved) {
         return;
      }

      resolved = true;
      try {
         Class<?> contents = Class.forName("net.kyori.adventure.text.object.ObjectContents");
         Class<?> builder = Class.forName("net.kyori.adventure.text.object.PlayerHeadObjectContents$Builder");
         playerHead = contents.getMethod("playerHead");
         builderName = builder.getMethod("name", String.class);
         builderId = builder.getMethod("id", UUID.class);
         builderHat = builder.getMethod("hat", Boolean.TYPE);
         builderBuild = builder.getMethod("build");
         componentObject = Component.class.getMethod("object", contents);
         supported = true;
      } catch (Throwable t) {
         supported = false;
         return;
      }

      try {
         Class<?> shadow = Class.forName("net.kyori.adventure.text.format.ShadowColor");
         Class<?> shadowLike = Class.forName("net.kyori.adventure.text.format.ShadowColorLike");
         shadowNone = shadow.getMethod("none").invoke(null);
         componentShadow = Component.class.getMethod("shadowColor", shadowLike);
      } catch (Throwable t) {
         componentShadow = null;
         shadowNone = null;
      }
   }

   private static Component head(String spec) {
      try {
         Object builder = playerHead.invoke(null);
         String s = spec.trim();
         if (s.length() == 36 && s.indexOf('-') > 0) {
            builderId.invoke(builder, UUID.fromString(s));
         } else {
            builderName.invoke(builder, s);
         }

         builderHat.invoke(builder, true);
         Component out = (Component)componentObject.invoke(null, builderBuild.invoke(builder));
         if (disableShadow && componentShadow != null) {
            out = (Component)componentShadow.invoke(out, shadowNone);
         }

         return out;
      } catch (Throwable t) {
         return Component.empty();
      }
   }

   /** Converte il testo con il parser dato e sostituisce ogni <head:..> con la testa corrispondente. */
   public static Component apply(String text, Function<String, Component> parser) {
      if (text == null || text.indexOf("<head:") < 0) {
         return parser.apply(text == null ? "" : text);
      }

      resolve();
      List<String> specs = new ArrayList<>();
      Matcher m = TOKEN.matcher(text);
      StringBuilder sb = new StringBuilder();
      int last = 0;
      while(m.find()) {
         sb.append(text, last, m.start());
         if (supported) {
            sb.append(OPEN).append(specs.size()).append(CLOSE);
            specs.add(m.group(1));
         }

         last = m.end();
         if (!supported && last < text.length() && text.charAt(last) == ' ') {
            ++last;
         }
      }

      sb.append(text, last, text.length());
      Component base = parser.apply(sb.toString());
      if (specs.isEmpty()) {
         return base;
      }

      return base.replaceText(TextReplacementConfig.builder().match(PLACEHOLDER).replacement((result, builder) -> {
         int idx = Integer.parseInt(result.group(1));
         return idx < specs.size() ? head(specs.get(idx)) : Component.empty();
      }).build());
   }
}
