package me.nothing.smpcore.systems.clearlag;

import me.nothing.smpcore.systems.smpcorelib.SmpCoreHost;
import me.nothing.smpcore.systems.smpcorelib.config.ConfigFile;

public abstract class ClearLagBase extends SmpCoreHost {
   protected ClearLagBase() {
      super("clearlag");
   }

   private ConfigFile config;
   private String prefix = "";

   protected abstract void start() throws Exception;

   protected void stop() {
   }

   public final void onEnable() {
      this.config = (new ConfigFile(this, "settings.yml")).load(true);
      this.prefix = this.config.yaml().getString("prefix", "");

      try {
         this.start();
      } catch (Exception e) {
         this.getLogger().severe("Startup failed - check plugins/" + this.getName() + "/settings.yml");
         e.printStackTrace();
         this.disableSelf();
      }

   }

   public final void onDisable() {
      this.stop();
      super.onDisable();
   }

   protected ConfigFile config() {
      return this.config;
   }

   protected void reloadPrefix() {
      this.prefix = this.config.yaml().getString("prefix", "");
   }

   protected String prefix() {
      return this.prefix;
   }
}
