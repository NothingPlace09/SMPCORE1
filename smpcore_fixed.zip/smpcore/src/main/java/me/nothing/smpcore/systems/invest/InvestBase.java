package me.nothing.smpcore.systems.invest;

import java.util.Map;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.SmpCoreHost;
import me.nothing.smpcore.systems.smpcorelib.config.ConfigFile;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.command.CommandSender;

public abstract class InvestBase extends SmpCoreHost {
   protected InvestBase() {
      super("invest");
   }

   private ConfigFile config;
   private EconomyHook economy;

   protected abstract void start() throws Exception;

   protected void stop() {
   }

   public final void onEnable() {
      this.config = (new ConfigFile(this, "settings.yml")).load(true, "ranks");
      this.economy = new EconomyHook(this);
      this.economy.hook();
      if (!this.economy.available()) {
         this.getLogger().severe("No economy plugin answered through Vault. SmpCoreInvest moves server money and has nothing to move without one.");
         this.disableSelf();
      } else {
         try {
            this.start();
         } catch (Exception e) {
            Logger logger = this.getLogger();
            String str = this.getName();
            logger.severe("Startup failed - check plugins/" + str + "/" + this.config.realPath());
            e.printStackTrace();
            this.disableSelf();
         }

      }
   }

   public final void onDisable() {
      this.stop();
      super.onDisable();
   }

   protected ConfigFile config() {
      return this.config;
   }

   public EconomyHook economy() {
      return this.economy;
   }

   protected String prefix() {
      String str = this.config.yaml().getString("prefix", "");
      return str == null ? "" : str;
   }

   public void message(CommandSender commandSender, String key, Map<String, String> map) {
      String str = this.config.yaml().getString("messages." + key, "");
      if (str != null && !str.isEmpty()) {
         commandSender.sendMessage(Text.chat(Text.apply(this.prefix() + str, map)));
      }
   }

   public void message(CommandSender commandSender, String str) {
      this.message(commandSender, str, Map.of());
   }

   public void messageLines(CommandSender commandSender, String str, Map<String, String> map) {
      for(String var6 : this.config.yaml().getStringList("messages." + str)) {
         commandSender.sendMessage(Text.chat(Text.apply(var6, map)));
      }

   }
}
