package me.nothing.smpcore.systems.invest;

import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import me.nothing.smpcore.systems.smpcorelib.gui.Menu;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

public final class ConfirmMenu extends Menu {
   private final InvestPlugin plugin;
   private final Mode mode;
   private final MenuConfig config;
   private final double amount;

   public ConfirmMenu(Player player, InvestPlugin investPlugin, Mode mode) {
      this(player, investPlugin, mode, (double)0.0F);
   }

   private ConfirmMenu(Player player, InvestPlugin investPlugin, Mode mode, double d) {
      super(player);
      this.plugin = investPlugin;
      this.mode = mode;
      this.amount = d;
      this.config = mode == ConfirmMenu.Mode.INVEST ? investPlugin.confirmInvestMenu() : investPlugin.confirmDeleteMenu();
   }

   protected String title() {
      return Text.apply(this.config.title(), this.values());
   }

   protected int rows() {
      return this.config.rows();
   }

   private Map<String, String> values() {
      Map map = this.plugin.values(this.viewer);
      if (this.mode != ConfirmMenu.Mode.INVEST) {
         return map;
      } else {
         InvestData investData = this.plugin.store().get(this.viewer.getUniqueId());
         String str = this.plugin.confirmInvestFile().yaml().getString("unset", "");
         map.put("amount", this.amount > (double)0.0F ? EconomyHook.format(this.amount) : str);
         map.put("new_income", EconomyHook.format(this.plugin.incomeFor(this.viewer, investData.invested() + Math.max((double)0.0F, this.amount))));
         return map;
      }
   }

   protected void draw() {
      this.config.render(this.getInventory(), this.values());
   }

   protected void onClick(InventoryClickEvent inventoryClickEvent) {
      if (this.clickedTopInventory(inventoryClickEvent)) {
         String str = this.config.actionAt(inventoryClickEvent.getSlot());
         if (str != null) {
            switch (str) {
               case "amount" -> this.askAmount();
               case "confirm" -> this.confirm();
               case "cancel" -> (new InvestMenu(this.viewer, this.plugin)).open();
               case "close" -> this.viewer.closeInventory();
            }

         }
      }
   }

   private void askAmount() {
      this.viewer.closeInventory();
      this.plugin.messageLines(this.viewer, "ask-amount", this.values());
      this.plugin.prompt().ask(this.viewer, (var1) -> {
         if (var1 == null) {
            this.plugin.say(this.viewer, "ask-cancelled");
            (new ConfirmMenu(this.viewer, this.plugin, ConfirmMenu.Mode.INVEST, this.amount)).open();
         } else {
            double d = EconomyHook.parseAmount(var1);
            if (Double.isFinite(d) && !(d <= (double)0.0F)) {
               (new ConfirmMenu(this.viewer, this.plugin, ConfirmMenu.Mode.INVEST, d)).open();
            } else {
               this.plugin.say(this.viewer, "invalid-amount");
               this.plugin.sounds().play(this.viewer, "deny");
               (new ConfirmMenu(this.viewer, this.plugin, ConfirmMenu.Mode.INVEST, this.amount)).open();
            }
         }
      });
   }

   private void confirm() {
      if (this.mode == ConfirmMenu.Mode.DELETE) {
         this.plugin.delete(this.viewer);
         (new InvestMenu(this.viewer, this.plugin)).open();
      } else if (this.amount <= (double)0.0F) {
         this.askAmount();
      } else {
         if (this.plugin.invest(this.viewer, this.amount)) {
            (new InvestMenu(this.viewer, this.plugin)).open();
         } else {
            this.refresh();
         }

      }
   }

   public static enum Mode {
      INVEST,
      DELETE;

      private static Mode[] $values() {
         return new Mode[]{INVEST, DELETE};
      }
   }
}
