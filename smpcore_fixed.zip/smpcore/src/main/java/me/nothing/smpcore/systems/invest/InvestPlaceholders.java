package me.nothing.smpcore.systems.invest;

import java.util.Locale;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

final class InvestPlaceholders extends PlaceholderExpansion {
   private final InvestPlugin plugin;

   private InvestPlaceholders(InvestPlugin investPlugin) {
      this.plugin = investPlugin;
   }

   private static InvestPlaceholders active;

   static synchronized boolean register(InvestPlugin investPlugin) {
      dropActive();
      InvestPlaceholders expansion = new InvestPlaceholders(investPlugin);
      boolean ok = expansion.register();
      if (ok) {
         active = expansion;
      }
      return ok;
   }

   static synchronized void dropActive() {
      if (active != null) {
         try {
            active.unregister();
         } catch (Throwable ignored) {
         }
         active = null;
      }
   }

   public String getIdentifier() {
      return "smpcoreinvest";
   }

   public String getAuthor() {
      return "nothing";
   }

   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onRequest(OfflinePlayer offlinePlayer, String params) {
      String str = params.toLowerCase(Locale.ROOT);
      if ("interval".equals(str)) {
         return String.valueOf(this.plugin.intervalSeconds());
      } else {
         if (offlinePlayer instanceof Player) {
            Player player = (Player)offlinePlayer;
            if (player.isOnline()) {
               InvestData investData = this.plugin.store().get(player.getUniqueId());
               String str2;
               switch (str) {
                  case "invested" -> str2 = EconomyHook.format(investData.invested());
                  case "invested_raw" -> str2 = String.valueOf(investData.invested());
                  case "income" -> str2 = EconomyHook.format(this.plugin.income(player, investData));
                  case "income_raw" -> str2 = String.valueOf(this.plugin.income(player, investData));
                  case "pending" -> str2 = EconomyHook.format(investData.pending());
                  case "pending_raw" -> str2 = String.valueOf(investData.pending());
                  case "max" -> str2 = EconomyHook.format(this.plugin.maxInvest(player));
                  case "autocollect" -> str2 = String.valueOf(investData.autoCollect());
                  default -> str2 = null;
               }

               return str2;
            }
         }

         return "";
      }
   }
}
