package me.nothing.smpcore.systems.voucher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.gui.Menu;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

public final class AdminMenu extends Menu {
   private final VoucherPlugin plugin;
   private final MenuConfig config;
   private final List<Integer> slots;
   private final char contentSymbol;
   private final SortMode sort;
   private final String search;
   private final List<VoucherDef> shown;
   private final int page;

   public AdminMenu(VoucherPlugin var1, Player var2, int var3, SortMode var4, String var5) {
      super(var2);
      this.plugin = var1;
      this.config = var1.adminMenuConfig();
      this.slots = var1.adminContentSlots();
      this.contentSymbol = var1.adminContentSymbol();
      this.sort = var4;
      this.search = var5 == null ? "" : var5;
      this.shown = filter(var1.vouchers(), this.search, var4);
      this.page = this.clamp(var3);
   }

   private static List<VoucherDef> filter(List<VoucherDef> var0, String var1, SortMode var2) {
      ArrayList arrayList = new ArrayList();
      String str = var1.toLowerCase(Locale.ROOT);

      for(VoucherDef var6 : var0) {
         if (str.isEmpty() || var6.id().contains(str) || var6.plainName().toLowerCase(Locale.ROOT).contains(str)) {
            arrayList.add(var6);
         }
      }

      arrayList.sort(var2.comparator());
      return arrayList;
   }

   private int perPage() {
      return Math.max(1, this.slots.size());
   }

   private int pageCount() {
      return Math.max(1, (int)Math.ceil((double)this.shown.size() / (double)this.perPage()));
   }

   private int clamp(int var1) {
      return Math.max(0, Math.min(var1, this.pageCount() - 1));
   }

   protected String title() {
      return Text.apply(this.config.title(), this.placeholders());
   }

   protected int rows() {
      return this.config.rows();
   }

   private Map<String, String> placeholders() {
      HashMap hashMap = new HashMap();
      hashMap.put("player", this.viewer.getName());
      hashMap.put("page", String.valueOf(this.page + 1));
      hashMap.put("max_page", String.valueOf(this.pageCount()));
      hashMap.put("total", String.valueOf(this.plugin.vouchers().size()));
      hashMap.put("count", String.valueOf(this.shown.size()));
      hashMap.put("search", this.search);
      hashMap.put("redeemed", String.valueOf(this.plugin.ledger().redeemedTotal()));
      hashMap.put("sort", this.plugin.adminFile().yaml().getString("sort-modes." + this.sort.key(), this.sort.key()));
      return hashMap;
   }

   protected void draw() {
      Map map = this.placeholders();
      this.config.render(this.getInventory(), map, this.contentSymbol);
      this.config.paging(this.getInventory(), this.page, this.pageCount());
      int i = this.page * this.perPage();

      for(int var3 = 0; var3 < this.slots.size(); ++var3) {
         int i2 = i + var3;
         this.getInventory().setItem((Integer)this.slots.get(var3), i2 >= this.shown.size() ? null : this.plugin.preview((VoucherDef)this.shown.get(i2)));
      }

   }

   protected void onClick(InventoryClickEvent var1) {
      if (this.clickedTopInventory(var1)) {
         String str = this.config.actionAt(var1.getSlot());
         if (str != null) {
            switch (str) {
               case "previous" -> this.turn(this.page - 1);
               case "next" -> this.turn(this.page + 1);
               case "close" -> this.viewer.closeInventory();
               case "sort" -> (new AdminMenu(this.plugin, this.viewer, 0, this.sort.next(), this.search)).open();
               case "search" -> this.askSearch();
               case "reload" -> this.reload();
               case "create" -> this.create();
            }

         } else {
            int i = this.slots.indexOf(var1.getSlot());
            if (i >= 0) {
               int i2 = this.page * this.perPage() + i;
               if (i2 < this.shown.size()) {
                  VoucherDef voucherDef = (VoucherDef)this.shown.get(i2);
                  if (var1.isShiftClick()) {
                     if (!this.plugin.allowed(this.viewer, this.plugin.givePermission())) {
                        this.plugin.denied(this.viewer);
                     } else {
                        int i3 = this.plugin.give(this.viewer, voucherDef, 1);
                        if (i3 > 0) {
                           this.plugin.playSound(this.viewer, "given");
                           this.plugin.message(this.viewer, "voucher-received", Map.of("voucher", voucherDef.displayName(), "voucher_id", voucherDef.id(), "amount", "1"));
                        }

                     }
                  } else if (!this.plugin.allowed(this.viewer, this.plugin.editPermission())) {
                     this.plugin.denied(this.viewer);
                  } else {
                     (new EditMenu(this.plugin, this.viewer, Draft.of(this.plugin, voucherDef), this.sort, this.search)).open();
                  }
               }
            }
         }
      }
   }

   private void reload() {
      if (!this.plugin.allowed(this.viewer, this.plugin.reloadPermission())) {
         this.plugin.denied(this.viewer);
      } else {
         int i = this.plugin.reload();
         this.plugin.playSound(this.viewer, "reload");
         this.plugin.message(this.viewer, "reloaded", Map.of("vouchers", String.valueOf(i)));
         Scheduler.atEntity(this.plugin, this.viewer, () -> (new AdminMenu(this.plugin, this.viewer, 0, this.sort, this.search)).open());
      }
   }

   private void create() {
      if (!this.plugin.allowed(this.viewer, this.plugin.editPermission())) {
         this.plugin.denied(this.viewer);
      } else {
         (new EditMenu(this.plugin, this.viewer, Draft.blank(), this.sort, this.search)).open();
      }
   }

   private void askSearch() {
      this.viewer.closeInventory();
      this.plugin.message(this.viewer, "editor-input", Map.of("cancel", this.plugin.prompt().cancelWord()));
      this.plugin.prompt().ask(this.viewer, (var1) -> (new AdminMenu(this.plugin, this.viewer, 0, this.sort, var1 == null ? "" : var1)).open());
   }

   private void turn(int var1) {
      int i = this.clamp(var1);
      if (i != this.page) {
         (new AdminMenu(this.plugin, this.viewer, i, this.sort, this.search)).open();
      }
   }
}
