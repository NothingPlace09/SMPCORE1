package me.nothing.smpcore.systems.clearlag;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.AbstractVillager;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Item;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;

public final class ClearLagPlugin extends ClearLagBase {
   private Scheduler.Task cycleTask;
   private final List<Scheduler.Task> pending = new ArrayList();
   private int intervalSeconds;
   private List<Integer> warnAt;
   private boolean clearItems;
   private boolean clearArrows;
   private boolean clearOrbs;
   private boolean clearCreatures;
   private int graceSeconds;
   private int keepNearPlayers;
   private List<String> worlds;
   private Set<String> creatureExceptions;
   private long nextSweepAt;
   private volatile int lastRemoved;

   protected void start() {
      this.applySettings();
      long l = (long)this.intervalSeconds * 20L;
      this.cycleTask = Scheduler.timer(this, this::beginCycle, l, l);
      this.nextSweepAt = System.currentTimeMillis() + (long)this.intervalSeconds * 1000L;
      if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         if (ClearLagPlaceholders.register(this)) {
            this.getLogger().info("PlaceholderAPI hooked: %smpcoreclearlag_...% is available.");
         } else {
            this.getLogger().warning("PlaceholderAPI is installed but refused the expansion.");
         }
      }

      Logger logger = this.getLogger();
      int i = this.intervalSeconds;
      logger.info("Clearing every " + i + "s in " + (this.worlds.isEmpty() ? "all worlds" : this.worlds.size() + " world(s)") + (this.clearCreatures ? ", creatures included." : "."));
   }

   private void applySettings() {
      this.intervalSeconds = Math.max(30, this.config().yaml().getInt("interval-seconds", 300));
      this.warnAt = this.config().yaml().getIntegerList("warn-seconds-before");
      this.clearItems = this.config().yaml().getBoolean("clear.dropped-items", true);
      this.clearArrows = this.config().yaml().getBoolean("clear.arrows", true);
      this.clearOrbs = this.config().yaml().getBoolean("clear.experience-orbs", true);
      this.clearCreatures = this.config().yaml().getBoolean("clear.creatures", false);
      this.graceSeconds = Math.max(0, this.config().yaml().getInt("grace-seconds", 0));
      this.keepNearPlayers = Math.max(0, this.config().yaml().getInt("creatures.keep-near-players", 16));
      this.worlds = this.config().yaml().getStringList("worlds");
      this.creatureExceptions = new HashSet();

      for(String var2 : this.config().yaml().getStringList("creatures.never-remove")) {
         this.creatureExceptions.add(var2.trim().toUpperCase(Locale.ROOT));
      }

   }

   protected void stop() {
      try {
         ClearLagPlaceholders.dropActive();
      } catch (Throwable ignored) {
      }
      if (this.cycleTask != null) {
         this.cycleTask.cancel();
      }

      this.pending.forEach(Scheduler.Task::cancel);
      this.pending.clear();
   }

   private void beginCycle() {
      this.pending.forEach(Scheduler.Task::cancel);
      this.pending.clear();
      int i = 0;

      for(int var3 : this.warnAt) {
         if (var3 > i) {
            i = var3;
         }
      }

      if (i >= this.intervalSeconds) {
         i = this.intervalSeconds - 1;
      }

      for(int var7 : this.warnAt) {
         if (var7 > 0 && var7 <= i) {
            long l = (long)(i - var7) * 20L;
            this.pending.add(Scheduler.later(this, () -> this.warn(var7), l));
         }
      }

      this.pending.add(Scheduler.later(this, this::sweep, (long)i * 20L));
      this.nextSweepAt = System.currentTimeMillis() + (long)i * 1000L;
   }

   private void warn(int i) {
      Map map = Map.of("seconds", String.valueOf(i));
      YamlConfiguration yamlConfiguration = this.config().yaml();
      String str = yamlConfiguration.getString("messages.warning", "");
      String str2 = yamlConfiguration.getBoolean("action-bar.enabled", false) ? yamlConfiguration.getString("action-bar.warning", "") : "";
      boolean flag = yamlConfiguration.getBoolean("action-bar.ignore-mute", true);
      String str3 = yamlConfiguration.getString("warning-sound.sound", "");
      float f = (float)yamlConfiguration.getDouble("warning-sound.volume", (double)1.0F);
      float f2 = (float)yamlConfiguration.getDouble("warning-sound.pitch", (double)1.0F);
      String str4 = yamlConfiguration.getString("mute-permission", "smpcoreclearlag.mute");
      String str5 = str != null && !str.isEmpty() ? Text.chat(Text.apply(this.prefix() + str, map)) : null;
      String str6 = str2 != null && !str2.isEmpty() ? Text.apply(str2, map) : null;

      for(Player var14 : Bukkit.getOnlinePlayers()) {
         boolean flag2 = var14.hasPermission(str4);
         boolean flag3 = false;
         if (str5 != null && !flag2) {
            var14.sendMessage(str5);
            flag3 = true;
         }

         if (str6 != null && (!flag2 || flag)) {
            Text.actionBar(var14, str6);
            flag3 = true;
         }

         if (flag3 && str3 != null && !str3.isEmpty()) {
            var14.playSound(var14.getLocation(), str3, f, f2);
         }
      }

   }

   private void sweep() {
      this.nextSweepAt = System.currentTimeMillis() + (long)this.intervalSeconds * 1000L;
      if (Scheduler.folia()) {
         this.sweepRegionweise();
      } else {
         int i = 0;

         for(World var3 : this.targetWorlds()) {
            for(Entity var5 : var3.getEntities()) {
               if (this.shouldRemove(var5)) {
                  var5.remove();
                  ++i;
               }
            }
         }

         this.lastRemoved = i;
         this.broadcast("cleared", Map.of("amount", String.valueOf(i)));
      }
   }

   private void sweepRegionweise() {
      ArrayList<Chunk> arrayList = new ArrayList<>();

      for(World var3 : this.targetWorlds()) {
         Collections.addAll(arrayList, var3.getLoadedChunks());
      }

      AtomicInteger atomicInteger = new AtomicInteger();

      for(Chunk var4 : arrayList) {
         Location location = new Location(var4.getWorld(), (double)((var4.getX() << 4) + 8), (double)64.0F, (double)((var4.getZ() << 4) + 8));
         Scheduler.atLocation(this, location, () -> {
            for(Entity var6x : var4.getEntities()) {
               if (this.shouldRemove(var6x)) {
                  var6x.remove();
                  atomicInteger.incrementAndGet();
               }
            }

         });
      }

      Scheduler.later(this, () -> {
         this.lastRemoved = atomicInteger.get();
         this.broadcast("cleared", Map.of("amount", String.valueOf(this.lastRemoved)));
      }, 20L);
   }

   private boolean shouldRemove(Entity entity) {
      if (entity instanceof Item item) {
         return this.clearItems && item.getTicksLived() >= this.graceSeconds * 20;
      } else if (entity instanceof AbstractArrow) {
         return this.clearArrows;
      } else if (entity instanceof ExperienceOrb) {
         return this.clearOrbs;
      } else if (!(entity instanceof Mob)) {
         return false;
      } else {
         Mob mob = (Mob)entity;
         return this.clearCreatures && this.darfWeg(mob);
      }
   }

   private boolean darfWeg(Mob mob) {
      if (mob.getCustomName() != null) {
         return false;
      } else {
         if (mob instanceof Tameable) {
            Tameable tameable = (Tameable)mob;
            if (tameable.isTamed()) {
               return false;
            }
         }

         if (!mob.isLeashed() && !mob.isInsideVehicle() && mob.getPassengers().isEmpty()) {
            if (!(mob instanceof AbstractVillager) && !mob.hasMetadata("NPC")) {
               if (mob instanceof Boss) {
                  return false;
               } else if (this.creatureExceptions.contains(mob.getType().name())) {
                  return false;
               } else {
                  if (this.keepNearPlayers > 0) {
                     double d = (double)this.keepNearPlayers * (double)this.keepNearPlayers;

                     for(Player var5 : mob.getWorld().getPlayers()) {
                        if (var5.getLocation().distanceSquared(mob.getLocation()) <= d) {
                           return false;
                        }
                     }
                  }

                  return true;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public boolean onCommand(CommandSender commandSender, Command command, String label, String[] strArr) {
      if (strArr.length == 0) {
         long l = Math.max(0L, this.nextSweepAt - System.currentTimeMillis());
         this.message(commandSender, "next", Map.of("time", alsZeit(l / 1000L)));
         return true;
      } else {
         String str = strArr[0].toLowerCase(Locale.ROOT);
         if (!str.equals("time") && !str.equals("next") && !str.equals("when")) {
            if (!commandSender.hasPermission("smpcoreclearlag.admin")) {
               this.message(commandSender, "no-permission");
               return true;
            } else {
               switch (str) {
                  case "now":
                     this.pending.forEach(Scheduler.Task::cancel);
                     this.pending.clear();
                     this.sweep();
                     this.getLogger().info(commandSender.getName() + " ran a clear-lag sweep by hand.");
                     break;
                  case "reload":
                     this.config().load(true);
                     this.applySettings();
                     this.message(commandSender, "reloaded");
                     break;
                  default:
                     this.message(commandSender, "usage", Map.of("command", "/" + label));
               }

               return true;
            }
         } else {
            long l = Math.max(0L, this.nextSweepAt - System.currentTimeMillis());
            this.message(commandSender, "next", Map.of("time", alsZeit(l / 1000L)));
            return true;
         }
      }
   }

   public List<String> onTabComplete(CommandSender commandSender, Command command, String alias, String[] strArr) {
      if (strArr.length != 1) {
         return List.of();
      } else {
         ArrayList<String> arrayList = new ArrayList<>(List.of("time"));
         if (commandSender.hasPermission("smpcoreclearlag.admin")) {
            arrayList.add("now");
            arrayList.add("reload");
         }

         String str = strArr[0].toLowerCase(Locale.ROOT);
         ArrayList<String> arrayList2 = new ArrayList<>();

         for(String var9 : arrayList) {
            if (var9.startsWith(str)) {
               arrayList2.add(var9);
            }
         }

         return arrayList2;
      }
   }

   long secondsToNextSweep() {
      return Math.max(0L, this.nextSweepAt - System.currentTimeMillis()) / 1000L;
   }

   int intervalSeconds() {
      return this.intervalSeconds;
   }

   int lastRemoved() {
      return this.lastRemoved;
   }

   int worldCount() {
      return this.targetWorlds().size();
   }

   private static String alsZeit(long l) {
      return l < 60L ? l + "s" : l / 60L + "m " + l % 60L + "s";
   }

   private List<World> targetWorlds() {
      if (this.worlds.isEmpty()) {
         return new ArrayList(Bukkit.getWorlds());
      } else {
         ArrayList arrayList = new ArrayList();

         for(String var3 : this.worlds) {
            World world = Bukkit.getWorld(var3);
            if (world != null) {
               arrayList.add(world);
            }
         }

         return arrayList;
      }
   }

   private void broadcast(String key, Map<String, String> map) {
      String str = this.config().yaml().getString("messages." + key, "");
      if (str != null && !str.isEmpty()) {
         String str2 = Text.apply(this.prefix() + str, map);
         String str3 = this.config().yaml().getString("mute-permission", "smpcoreclearlag.mute");

         for(Player var7 : Bukkit.getOnlinePlayers()) {
            if (!var7.hasPermission(str3)) {
               var7.sendMessage(Text.chat(str2));
            }
         }

      }
   }

   private void message(CommandSender commandSender, String key, Map<String, String> map) {
      String str = this.config().yaml().getString("messages." + key, "");
      if (str != null && !str.isEmpty()) {
         commandSender.sendMessage(Text.chat(Text.apply(this.prefix() + str, map)));
      }
   }

   private void message(CommandSender commandSender, String str) {
      this.message(commandSender, str, Map.of());
   }
}
