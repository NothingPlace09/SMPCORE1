package me.nothing.smpcore.systems.tab;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/** Animazioni di tab/animations.yml: ogni animazione cambia testo ogni change-interval millisecondi. */
public final class TabAnimations {
   private static final class Anim {
      final long interval;
      final List<String> texts;

      Anim(long interval, List<String> texts) {
         this.interval = Math.max(50L, interval);
         this.texts = texts;
      }
   }

   private final Map<String, Anim> animations = new LinkedHashMap<>();

   public void load(File file) {
      this.animations.clear();
      if (file == null || !file.exists()) {
         return;
      }

      YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
      for(String name : yaml.getKeys(false)) {
         ConfigurationSection sec = yaml.getConfigurationSection(name);
         if (sec == null) {
            continue;
         }

         List<String> texts = new ArrayList<>(sec.getStringList("texts"));
         if (!texts.isEmpty()) {
            this.animations.put(name, new Anim(sec.getLong("change-interval", 1000L), texts));
         }
      }
   }

   /** Testo corrente dell'animazione, oppure null se non esiste. */
   public String frame(String name) {
      Anim anim = this.animations.get(name);
      if (anim == null) {
         return null;
      }

      int idx = (int)(System.currentTimeMillis() / anim.interval % (long)anim.texts.size());
      return anim.texts.get(idx);
   }

   /** Sostituisce ogni %animation:Nome% con il frame corrente. */
   public String apply(String text) {
      if (text == null || text.indexOf("%animation:") < 0) {
         return text;
      }

      StringBuilder out = new StringBuilder();
      int pos = 0;
      while(true) {
         int start = text.indexOf("%animation:", pos);
         if (start < 0) {
            out.append(text, pos, text.length());
            break;
         }

         int end = text.indexOf('%', start + 11);
         if (end < 0) {
            out.append(text, pos, text.length());
            break;
         }

         out.append(text, pos, start);
         String frame = this.frame(text.substring(start + 11, end));
         out.append(frame != null ? frame : text.substring(start, end + 1));
         pos = end + 1;
      }

      return out.toString();
   }
}
