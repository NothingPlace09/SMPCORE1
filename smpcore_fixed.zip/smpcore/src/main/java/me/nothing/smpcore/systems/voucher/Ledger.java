package me.nothing.smpcore.systems.voucher;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.storage.Storage;
import org.bukkit.plugin.Plugin;

public final class Ledger {
   private static final String NS_REDEEMED = "redeemed";
   private static final String NS_PLAYERS = "players";
   private static final String F_VOUCHER = "voucher";
   private static final String F_PLAYER = "player";
   private static final String F_NAME = "name";
   private static final String F_TIME = "time";
   private final Plugin plugin;
   private final Storage storage;
   private final boolean remember;
   private final long forgetAfterDays;
   private final Set<String> claimed = ConcurrentHashMap.newKeySet();
   private final Map<UUID, Map<String, String>> players = new ConcurrentHashMap();
   private final AtomicInteger redeemedTotal = new AtomicInteger();
   private final ExecutorService writer = Executors.newSingleThreadExecutor((var0) -> new Thread(var0, "SmpCoreVoucher-Save"));
   private final Map<String, Map<String, String>> nachzuholen = new ConcurrentHashMap();

   public Ledger(Plugin plugin, Storage storage, boolean flag, long l) {
      this.plugin = plugin;
      this.storage = storage;
      this.remember = flag;
      this.forgetAfterDays = Math.max(0L, l);
   }

   public void load() {
      this.claimed.clear();
      this.players.clear();
      this.redeemedTotal.set(0);
      long l = this.forgetAfterDays <= 0L ? 0L : System.currentTimeMillis() - this.forgetAfterDays * 86400000L;
      int i = 0;
      if (this.remember) {
         for(Map.Entry var5 : this.storage.readAll("redeemed").entrySet()) {
            if (l > 0L && zahl((String)((Map)var5.getValue()).get("time")) < l) {
               this.storage.delete("redeemed", (String)var5.getKey());
               ++i;
            } else {
               this.claimed.add((String)var5.getKey());
            }
         }
      }

      this.redeemedTotal.set(this.claimed.size());

      for(Map.Entry var9 : this.storage.readAll("players").entrySet()) {
         try {
            this.players.put(UUID.fromString((String)var9.getKey()), new ConcurrentHashMap((Map)var9.getValue()));
         } catch (IllegalArgumentException e) {
         }
      }

      if (this.remember) {
         Logger logger = this.plugin.getLogger();
         int i2 = this.claimed.size();
         logger.info("Voucher ledger: " + i2 + " serial(s) redeemed" + (i > 0 ? ", " + i + " forgotten by age" : "") + ", " + this.players.size() + " player record(s).");
      } else {
         this.plugin.getLogger().warning("security.remember-redeemed is off: a voucher that was duplicated can be redeemed again after a restart. Only turn this off if you know why.");
      }

      if (i > 0) {
         this.writer.execute(this::flushNow);
      }

   }

   private static long zahl(String str) {
      if (str != null && !str.isEmpty()) {
         try {
            return Long.parseLong(str.trim());
         } catch (NumberFormatException e) {
            return 0L;
         }
      } else {
         return 0L;
      }
   }

   public boolean claim(String str) {
      return str != null && !str.isEmpty() && this.claimed.add(str);
   }

   public void release(String str) {
      if (str != null) {
         this.claimed.remove(str);
      }

   }

   public boolean isRedeemed(String str) {
      return str != null && this.claimed.contains(str);
   }

   public void record(String str, String str2, UUID uUID, String str3, long l) {
      this.redeemedTotal.incrementAndGet();
      Map<String, String> map = this.players.computeIfAbsent(uUID, (var0) -> new ConcurrentHashMap<String, String>());
      map.put("name", str3 == null ? "" : str3);
      map.compute("n_" + str2, (var0, var1x) -> String.valueOf(zahl(var1x) + 1L));
      map.put("cd_" + str2, String.valueOf(l));
      LinkedHashMap linkedHashMap = new LinkedHashMap(map);
      LinkedHashMap linkedHashMap2 = new LinkedHashMap();
      linkedHashMap2.put("voucher", str2);
      linkedHashMap2.put("player", uUID.toString());
      linkedHashMap2.put("name", str3 == null ? "" : str3);
      linkedHashMap2.put("time", String.valueOf(l));
      this.writer.execute(() -> {
         try {
            if (this.remember) {
               this.storage.write("redeemed", str, linkedHashMap2);
            }

            this.storage.write("players", uUID.toString(), linkedHashMap);
         } catch (RuntimeException e) {
            this.nachzuholen.put("players\u0000" + String.valueOf(uUID), linkedHashMap);
            if (this.remember) {
               this.nachzuholen.put("redeemed\u0000" + str, linkedHashMap2);
            }

            this.plugin.getLogger().log(Level.SEVERE, "Could not write the voucher ledger - retrying when the server stops", e);
         }

      });
   }

   public int count(UUID uUID, String str) {
      Map map = (Map)this.players.get(uUID);
      return map == null ? 0 : (int)zahl((String)map.get("n_" + str));
   }

   public long last(UUID uUID, String str) {
      Map map = (Map)this.players.get(uUID);
      return map == null ? 0L : zahl((String)map.get("cd_" + str));
   }

   public int totalOf(UUID uUID) {
      Map<String, String> map = this.players.get(uUID);
      if (map == null) {
         return 0;
      } else {
         int i = 0;

         for(Map.Entry<String, String> var5 : map.entrySet()) {
            if (((String)var5.getKey()).startsWith("n_")) {
               i += (int)zahl((String)var5.getValue());
            }
         }

         return i;
      }
   }

   public int redeemedTotal() {
      return this.redeemedTotal.get();
   }

   public int knownPlayers() {
      return this.players.size();
   }

   public void flush() {
      this.writer.execute(this::flushNow);
   }

   private void flushNow() {
      try {
         this.storage.flush();
      } catch (RuntimeException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Could not save the voucher ledger", e);
      }

   }

   public void shutdown() {
      this.writer.shutdown();

      try {
         if (!this.writer.awaitTermination(10L, TimeUnit.SECONDS)) {
            this.plugin.getLogger().warning("Saving the voucher ledger did not finish within 10s.");
         }
      } catch (InterruptedException e) {
         Thread.currentThread().interrupt();
      }

      for(Map.Entry var2 : this.nachzuholen.entrySet()) {
         int i = ((String)var2.getKey()).indexOf(0);
         String str = ((String)var2.getKey()).substring(0, i);
         String str2 = ((String)var2.getKey()).substring(i + 1);

         try {
            this.storage.write(str, str2, (Map)var2.getValue());
         } catch (RuntimeException e) {
            this.plugin.getLogger().log(Level.SEVERE, "Ledger entry " + str + "/" + str2 + " is lost: " + e.getMessage(), e);
         }
      }

      this.storage.close();
   }
}
