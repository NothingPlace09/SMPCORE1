package me.nothing.smpcore.systems.smpcorelib;

import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Sostituisce il vecchio SmpCoreModule (che estendeva JavaPlugin): i plugin SmpCore* girano ora come
 * sistemi interni di SmpCore. Config, cartella dati e risorse arrivano da SystemHost;
 * scheduler ed eventi usano sempre il plugin reale (core()).
 */
public abstract class SmpCoreHost extends SystemHost {
   private boolean failed;

   protected SmpCoreHost(String systemId) {
      super(systemId);
   }

   /** Il plugin SmpCore vero, da usare per eventi/scheduler di Bukkit. */
   protected final JavaPlugin core() {
      return this.getCore();
   }

   /** Segna l'avvio come fallito: CoreSystemsModule non registra il comando e logga l'errore. */
   protected final void disableSelf() {
      this.failed = true;
      this.setEnabledState(false);
   }

   public final boolean failed() {
      return this.failed;
   }

   protected final boolean owns(PluginCommand pluginCommand) {
      return pluginCommand != null && this.getCore() != null && this.getCore().equals(pluginCommand.getPlugin());
   }
}
