package me.nothing.smpcore.systems.smpcorelib.platform;

import java.util.List;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class Players {
   private Players() {
   }

   public static void each(Plugin plugin, Consumer<Player> consumer) {
      for(Player var3 : List.copyOf(Bukkit.getOnlinePlayers())) {
         Scheduler.atEntity(plugin, var3, () -> consumer.accept(var3));
      }

   }
}
