package me.nothing.smpcore.systems.smpcorelib.text;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.entity.Player;

final class PapiBridge {
   private PapiBridge() {
   }

   static String apply(Player player, String str) {
      return PlaceholderAPI.setPlaceholders(player, str);
   }
}
