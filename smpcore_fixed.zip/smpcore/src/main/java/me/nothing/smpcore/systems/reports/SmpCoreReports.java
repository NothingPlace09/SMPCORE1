package me.nothing.smpcore.systems.reports;

import me.nothing.smpcore.systems.SystemHost;

public final class SmpCoreReports extends SystemHost {
   private static SmpCoreReports instance;
   private DatabaseManager databaseManager;
   private CooldownManager cooldownManager;

   public SmpCoreReports() {
      super("reports");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.databaseManager = new DatabaseManager(this);
      this.databaseManager.initialize();
      me.nothing.smpcore.data.PlayerDatabase.registerContributor("reports", new me.nothing.smpcore.data.PlayerDatabase.Contributor() {
         public void export(java.util.UUID id, org.bukkit.configuration.ConfigurationSection out) {
            java.sql.Connection c = SmpCoreReports.this.databaseManager.getConnection();
            if (c != null) {
               java.util.List<java.util.Map<String, Object>> rows = new java.util.ArrayList();

               try (java.sql.PreparedStatement ps = c.prepareStatement("SELECT * FROM reports WHERE reporter_uuid = ? OR reported_uuid = ? ORDER BY id")) {
                  ps.setString(1, id.toString());
                  ps.setString(2, id.toString());

                  try (java.sql.ResultSet rs = ps.executeQuery()) {
                     java.sql.ResultSetMetaData md = rs.getMetaData();

                     while(rs.next()) {
                        java.util.Map<String, Object> row = new java.util.LinkedHashMap();

                        for(int i = 1; i <= md.getColumnCount(); ++i) {
                           row.put(md.getColumnLabel(i).toLowerCase(java.util.Locale.ROOT), rs.getObject(i));
                        }

                        rows.add(row);
                     }
                  }
               } catch (java.sql.SQLException e) {
                  throw new RuntimeException(e);
               }

               if (!rows.isEmpty()) {
                  out.set("entries", rows);
               }
            }
         }

         public void apply(java.util.UUID id, org.bukkit.configuration.ConfigurationSection in) {
            java.sql.Connection c = SmpCoreReports.this.databaseManager.getConnection();
            if (c != null) {
               try {
                  java.util.Set<String> columns = new java.util.HashSet();

                  try (java.sql.Statement st = c.createStatement(); java.sql.ResultSet rs = st.executeQuery("SELECT * FROM reports WHERE 1 = 0")) {
                     java.sql.ResultSetMetaData md = rs.getMetaData();

                     for(int i = 1; i <= md.getColumnCount(); ++i) {
                        columns.add(md.getColumnLabel(i).toLowerCase(java.util.Locale.ROOT));
                     }
                  }

                  try (java.sql.PreparedStatement del = c.prepareStatement("DELETE FROM reports WHERE reporter_uuid = ? OR reported_uuid = ?")) {
                     del.setString(1, id.toString());
                     del.setString(2, id.toString());
                     del.executeUpdate();
                  }

                  if (in != null) {
                     for(java.util.Map<?, ?> row : in.getMapList("entries")) {
                        java.util.List<String> cols = new java.util.ArrayList();
                        java.util.List<Object> vals = new java.util.ArrayList();

                        for(java.util.Map.Entry<?, ?> e : row.entrySet()) {
                           String col = String.valueOf(e.getKey()).toLowerCase(java.util.Locale.ROOT);
                           if (columns.contains(col)) {
                              cols.add(col);
                              vals.add(e.getValue());
                           }
                        }

                        if (!cols.isEmpty()) {
                           String sql = "INSERT INTO reports (" + String.join(",", cols) + ") VALUES (" + String.join(",", java.util.Collections.nCopies(cols.size(), "?")) + ")";

                           try (java.sql.PreparedStatement ins = c.prepareStatement(sql)) {
                              for(int i = 0; i < vals.size(); ++i) {
                                 ins.setObject(i + 1, vals.get(i));
                              }

                              ins.executeUpdate();
                           }
                        }
                     }
                  }
               } catch (java.sql.SQLException e) {
                  throw new RuntimeException(e);
               }
            }
         }
      });
      this.cooldownManager = new CooldownManager(this);
      this.getServer().getPluginManager().registerEvents(new GUIListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new InventoryListener(this), this.getCore());
      this.getLogger().info("SmpCoreReports Enabled");
   }

   public void stop() {
      if (this.databaseManager != null) {
         this.databaseManager.close();
      }

   }

   public static SmpCoreReports getInstance() {
      return instance;
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public CooldownManager getCooldownManager() {
      return this.cooldownManager;
   }
}
