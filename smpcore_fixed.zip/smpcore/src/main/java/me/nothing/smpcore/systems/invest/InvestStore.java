package me.nothing.smpcore.systems.invest;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.systems.smpcorelib.storage.Storage;

public final class InvestStore {
   private static final String NAMESPACE = "invest";
   private final Storage storage;
   private final Map<UUID, InvestData> cache = new ConcurrentHashMap();

   public InvestStore(Storage storage) {
      this.storage = storage;
      me.nothing.smpcore.data.PlayerDatabase.registerContributor("invest", new me.nothing.smpcore.data.PlayerDatabase.Contributor() {
         public void export(UUID id, org.bukkit.configuration.ConfigurationSection out) {
            InvestData d = (InvestData)InvestStore.this.cache.get(id);
            if (d == null) {
               d = InvestStore.this.load(id);
            }

            if (!d.empty()) {
               out.set("invested", d.invested());
               out.set("pending", d.pending());
               out.set("extra-max", d.extraMax());
               out.set("auto-collect", d.autoCollect());
            }
         }

         public void apply(UUID id, org.bukkit.configuration.ConfigurationSection in) {
            InvestData d = new InvestData();
            if (in != null) {
               d.setInvested(in.getDouble("invested", (double)0.0F));
               d.setPending(in.getDouble("pending", (double)0.0F));
               d.setExtraMax(in.getDouble("extra-max", (double)0.0F));
               d.setAutoCollect(in.getBoolean("auto-collect", false));
            }

            InvestStore.this.cache.put(id, d);
            InvestStore.this.save(id);
         }
      });
   }

   public InvestData get(UUID uUID) {
      return (InvestData)this.cache.computeIfAbsent(uUID, this::load);
   }

   public Map<UUID, InvestData> loaded() {
      return this.cache;
   }

   private InvestData load(UUID uUID) {
      InvestData investData = new InvestData();
      Map map = this.storage.read("invest", uUID.toString());
      if (map.isEmpty()) {
         return investData;
      } else {
         investData.setInvested(number((String)map.get("invested")));
         investData.setPending(number((String)map.get("pending")));
         investData.setExtraMax(number((String)map.get("extra-max")));
         investData.setAutoCollect(Boolean.parseBoolean((String)map.getOrDefault("auto-collect", "false")));
         return investData;
      }
   }

   private static double number(String str) {
      if (str != null && !str.isEmpty()) {
         try {
            return Double.parseDouble(str);
         } catch (NumberFormatException e) {
            return (double)0.0F;
         }
      } else {
         return (double)0.0F;
      }
   }

   public void save(UUID uUID) {
      InvestData investData = (InvestData)this.cache.get(uUID);
      if (investData != null) {
         if (investData.empty()) {
            this.storage.delete("invest", uUID.toString());
         } else {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            linkedHashMap.put("invested", String.valueOf(investData.invested()));
            linkedHashMap.put("pending", String.valueOf(investData.pending()));
            linkedHashMap.put("extra-max", String.valueOf(investData.extraMax()));
            linkedHashMap.put("auto-collect", String.valueOf(investData.autoCollect()));
            this.storage.write("invest", uUID.toString(), linkedHashMap);
         }
      }
   }

   public void unload(UUID uUID) {
      this.save(uUID);
      this.cache.remove(uUID);
   }

   public void saveAll() {
      for(UUID var2 : this.cache.keySet()) {
         this.save(var2);
      }

      this.storage.flush();
   }

   public double reset(UUID uUID) {
      InvestData investData = (InvestData)this.cache.get(uUID);
      if (investData != null) {
         double d = investData.invested();
         investData.setInvested((double)0.0F);
         investData.setPending((double)0.0F);
         this.save(uUID);
         return d;
      } else {
         Map map = this.storage.read("invest", uUID.toString());
         double d = number((String)map.get("invested"));
         this.storage.delete("invest", uUID.toString());
         return d;
      }
   }

   public void addExtraMax(UUID uUID, double d) {
      InvestData investData = (InvestData)this.cache.get(uUID);
      if (investData != null) {
         investData.setExtraMax(investData.extraMax() + d);
         this.save(uUID);
      } else {
         HashMap hashMap = new HashMap(this.storage.read("invest", uUID.toString()));
         hashMap.put("extra-max", String.valueOf(number((String)hashMap.get("extra-max")) + d));
         hashMap.putIfAbsent("invested", "0.0");
         hashMap.putIfAbsent("pending", "0.0");
         hashMap.putIfAbsent("auto-collect", "false");
         this.storage.write("invest", uUID.toString(), hashMap);
      }
   }
}
