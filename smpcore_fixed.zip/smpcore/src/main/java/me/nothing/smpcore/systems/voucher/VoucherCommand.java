package me.nothing.smpcore.systems.voucher;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class VoucherCommand implements CommandExecutor, TabCompleter {
   private final VoucherPlugin plugin;

   public VoucherCommand(VoucherPlugin var1) {
      this.plugin = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length == 0) {
         this.plugin.message(var1, "usage");
         return true;
      } else {
         switch (var4[0].toLowerCase(Locale.ROOT)) {
            case "admin":
            case "menu":
               this.admin(var1);
               break;
            case "list":
               this.list(var1);
               break;
            case "give":
               this.give(var1, var4);
               break;
            case "create":
               this.create(var1, var4);
               break;
            case "delete":
            case "remove":
               this.delete(var1, var4);
               break;
            case "reload":
               this.reload(var1);
               break;
            default:
               this.plugin.message(var1, "usage");
         }

         return true;
      }
   }

   private void admin(CommandSender var1) {
      if (!this.plugin.allowed(var1, this.plugin.menuPermission())) {
         this.plugin.denied(var1);
      } else if (var1 instanceof Player) {
         Player player = (Player)var1;
         this.plugin.openAdmin(player);
      } else {
         this.plugin.message(var1, "players-only");
      }
   }

   private void list(CommandSender var1) {
      if (!this.plugin.allowed(var1, this.plugin.menuPermission())) {
         this.plugin.denied(var1);
      } else if (this.plugin.vouchers().isEmpty()) {
         this.plugin.message(var1, "list-empty");
      } else {
         this.plugin.message(var1, "list-header", Map.of("count", String.valueOf(this.plugin.vouchers().size())));
         String str = this.plugin.config().yaml().getString("messages.list-entry", "");
         if (str != null && !str.isEmpty()) {
            for(VoucherDef var4 : this.plugin.vouchers()) {
               var1.sendMessage(Text.chat(Text.apply(str, Map.of("voucher", var4.displayName(), "voucher_id", var4.id(), "state", this.plugin.config().yaml().getString(var4.enabled() ? "messages.state-on" : "messages.state-off", "")))));
            }

         }
      }
   }

   private void reload(CommandSender var1) {
      if (!this.plugin.allowed(var1, this.plugin.reloadPermission())) {
         this.plugin.denied(var1);
      } else {
         int i = this.plugin.reload();
         if (var1 instanceof Player) {
            Player player = (Player)var1;
            this.plugin.playSound(player, "reload");
         }

         this.plugin.message(var1, "reloaded", Map.of("vouchers", String.valueOf(i)));
      }
   }

   private void give(CommandSender var1, String[] var2) {
      if (!this.plugin.allowed(var1, this.plugin.givePermission())) {
         this.plugin.denied(var1);
      } else if (var2.length < 2) {
         this.plugin.message(var1, "usage");
      } else {
         VoucherDef voucherDef = this.plugin.voucher(var2[1]);
         if (voucherDef != null && var2.length == 2) {
            if (var1 instanceof Player) {
               Player player = (Player)var1;
               this.hand(var1, List.of(player), voucherDef, 1);
            } else {
               this.plugin.message(var1, "players-only");
            }
         } else {
            ArrayList<Player> arrayList = new ArrayList<>();
            if (!var2[1].equals("*") && !var2[1].equalsIgnoreCase("all")) {
               Player player = Bukkit.getPlayerExact(var2[1]);
               if (player == null) {
                  this.plugin.message(var1, "player-not-found", Map.of("player", var2[1]));
                  return;
               }

               arrayList.add(player);
            } else {
               arrayList.addAll(Bukkit.getOnlinePlayers());
            }

            if (var2.length < 3) {
               this.plugin.message(var1, "usage");
            } else {
               VoucherDef voucherDef2 = this.plugin.voucher(var2[2]);
               if (voucherDef2 == null) {
                  this.plugin.message(var1, "voucher-not-found", Map.of("voucher_id", var2[2]));
               } else {
                  int i = 1;
                  if (var2.length > 3) {
                     try {
                        i = Integer.parseInt(var2[3]);
                     } catch (NumberFormatException e) {
                        this.plugin.message(var1, "invalid-amount", Map.of("amount", var2[3]));
                        return;
                     }

                     if (i < 1 || i > 64) {
                        this.plugin.message(var1, "invalid-amount", Map.of("amount", var2[3]));
                        return;
                     }
                  }

                  this.hand(var1, arrayList, voucherDef2, i);
               }
            }
         }
      }
   }

   private void hand(CommandSender var1, List<Player> var2, VoucherDef var3, int var4) {
      int i = 0;

      for(Player var7 : var2) {
         int i2 = this.plugin.give(var7, var3, var4);
         i += i2;
         if (i2 > 0) {
            this.plugin.playSound(var7, "given");
            this.plugin.message(var7, "voucher-received", Map.of("voucher", var3.displayName(), "voucher_id", var3.id(), "amount", String.valueOf(i2)));
         }
      }

      if (i <= 0) {
         this.plugin.message(var1, "voucher-not-found", Map.of("voucher_id", var3.id()));
      } else if (var2.size() != 1 || !((Player)var2.get(0)).equals(var1)) {
         this.plugin.message(var1, "voucher-given", Map.of("voucher", var3.displayName(), "voucher_id", var3.id(), "amount", String.valueOf(i), "player", var2.size() == 1 ? ((Player)var2.get(0)).getName() : String.valueOf(var2.size())));
      }
   }

   private void create(CommandSender var1, String[] var2) {
      if (!this.plugin.allowed(var1, this.plugin.editPermission())) {
         this.plugin.denied(var1);
      } else if (var1 instanceof Player) {
         Player player = (Player)var1;
         if (var2.length < 2) {
            this.plugin.message(var1, "usage");
         } else {
            Draft draft = Draft.blank();
            if (!draft.id(var2[1])) {
               this.plugin.message(var1, "invalid-id");
            } else if (this.plugin.voucher(draft.id()) != null) {
               this.plugin.message(var1, "voucher-exists", Map.of("voucher_id", draft.id()));
            } else if (!draft.capture(this.plugin.tags(), player.getInventory().getItemInMainHand())) {
               this.plugin.message(var1, "editor-no-item");
            } else {
               draft.displayName(draft.id());
               draft.save(this.plugin);
               this.plugin.playSound(player, "saved");
               this.plugin.message(var1, "voucher-created", Map.of("voucher_id", draft.id()));
            }
         }
      } else {
         this.plugin.message(var1, "players-only");
      }
   }

   private void delete(CommandSender var1, String[] var2) {
      if (!this.plugin.allowed(var1, this.plugin.editPermission())) {
         this.plugin.denied(var1);
      } else if (var2.length < 2) {
         this.plugin.message(var1, "usage");
      } else {
         VoucherDef voucherDef = this.plugin.voucher(var2[1]);
         if (voucherDef == null) {
            this.plugin.message(var1, "voucher-not-found", Map.of("voucher_id", var2[1]));
         } else {
            this.plugin.deleteVoucher(voucherDef.id());
            if (var1 instanceof Player) {
               Player player = (Player)var1;
               this.plugin.playSound(player, "delete");
            }

            this.plugin.message(var1, "voucher-deleted", Map.of("voucher_id", voucherDef.id()));
         }
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      ArrayList<String> arrayList = new ArrayList<>();
      if (var4.length == 1) {
         if (this.plugin.allowed(var1, this.plugin.menuPermission())) {
            arrayList.add("admin");
            arrayList.add("list");
         }

         if (this.plugin.allowed(var1, this.plugin.givePermission())) {
            arrayList.add("give");
         }

         if (this.plugin.allowed(var1, this.plugin.editPermission())) {
            arrayList.add("create");
            arrayList.add("delete");
         }

         if (this.plugin.allowed(var1, this.plugin.reloadPermission())) {
            arrayList.add("reload");
         }
      } else if (var4[0].equalsIgnoreCase("give")) {
         switch (var4.length) {
            case 2:
               arrayList.addAll(this.ids());
               arrayList.add("*");
               arrayList.addAll(this.visible(var1));
               break;
            case 3:
               arrayList.addAll(this.ids());
               break;
            case 4:
               arrayList.addAll(List.of("1", "4", "16"));
               break;
            default:
               return Collections.emptyList();
         }
      } else {
         if (!var4[0].equalsIgnoreCase("delete") || var4.length != 2) {
            return Collections.emptyList();
         }

         arrayList.addAll(this.ids());
      }

      String str = var4[var4.length - 1].toLowerCase(Locale.ROOT);
      ArrayList<String> arrayList2 = new ArrayList<>();

      for(String var9 : arrayList) {
         if (var9.toLowerCase(Locale.ROOT).startsWith(str)) {
            arrayList2.add(var9);
         }
      }

      return arrayList2;
   }

   private List<String> ids() {
      ArrayList<String> arrayList = new ArrayList<>();

      for(VoucherDef var3 : this.plugin.vouchers()) {
         arrayList.add(var3.id());
      }

      return arrayList;
   }

   private List<String> visible(CommandSender var1) {
      ArrayList<String> arrayList = new ArrayList<>();

      for(Player var4 : Bukkit.getOnlinePlayers()) {
         if (var1 instanceof Player var5) {
            if (!var5.canSee(var4)) {
               continue;
            }
         }

         arrayList.add(var4.getName());
      }

      return arrayList;
   }
}
