package me.nothing.smpcore.systems.smpcorelib.text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class Text {
   private static final Pattern HEX = Pattern.compile("&#([0-9a-fA-F]{6})");
   private static final boolean REICH = pruefeReich();

   private Text() {
   }

   public static String toLegacy(String var0) {
      if (var0 == null) {
         return "";
      } else {
         Matcher matcher = HEX.matcher(var0);
         StringBuilder stringBuilder = new StringBuilder(var0.length() + 16);

         while(matcher.find()) {
            StringBuilder stringBuilder2 = new StringBuilder("§x");

            for(char var7 : matcher.group(1).toCharArray()) {
               stringBuilder2.append('§').append(var7);
            }

            matcher.appendReplacement(stringBuilder, Matcher.quoteReplacement(stringBuilder2.toString()));
         }

         matcher.appendTail(stringBuilder);
         return stringBuilder.toString().replaceAll("&([0-9a-fA-Fk-orK-OR])", "§$1");
      }
   }

   public static String chat(String var0) {
      return toLegacy(var0);
   }

   public static String item(String var0) {
      return "§r" + toLegacy(var0);
   }

   public static List<String> lore(List<String> var0) {
      ArrayList arrayList = new ArrayList(var0.size());

      for(String var3 : var0) {
         arrayList.add(item(var3));
      }

      return arrayList;
   }

   public static String apply(String var0, Map<String, String> var1) {
      if (var0 != null && !var0.isEmpty() && !var1.isEmpty()) {
         String str = var0;

         for(Map.Entry var4 : var1.entrySet()) {
            String str2 = "%" + (String)var4.getKey() + "%";
            if (str.contains(str2)) {
               str = str.replace(str2, (CharSequence)(var4.getValue() == null ? "" : (CharSequence)var4.getValue()));
            }
         }

         return str;
      } else {
         return var0 == null ? "" : var0;
      }
   }

   public static List<String> apply(List<String> var0, Map<String, String> var1) {
      ArrayList arrayList = new ArrayList(var0.size());

      for(String var4 : var0) {
         arrayList.add(apply(var4, var1));
      }

      return arrayList;
   }

   public static String strip(String var0) {
      return toLegacy(var0).replaceAll("§[0-9a-fA-Fk-orK-ORx]", "");
   }

   private static boolean pruefeReich() {
      try {
         Class.forName("net.md_5.bungee.api.chat.BaseComponent");
         CommandSender.class.getMethod("spigot");
         return true;
      } catch (NoSuchMethodException | ClassNotFoundException e) {
         return false;
      }
   }

   public static boolean reich() {
      return REICH;
   }

   public static void actionBar(Player var0, String var1) {
      if (var0 != null) {
         if (REICH) {
            RichText.actionBar(var0, toLegacy(var1));
         } else {
            var0.sendMessage(toLegacy(var1));
         }

      }
   }

   public static void sendClickable(CommandSender var0, String var1, String var2, String var3) {
      sende(var0, var1, var2, var3, false);
   }

   public static void sendLink(CommandSender var0, String var1, String var2, String var3) {
      sende(var0, var1, var2, var3, true);
   }

   private static void sende(CommandSender var0, String var1, String var2, String var3, boolean var4) {
      if (var0 != null) {
         if (REICH) {
            RichText.clickable(var0, toLegacy(var1), var2, var3 == null ? null : toLegacy(var3), var4);
         } else {
            var0.sendMessage(toLegacy(var1));
         }

      }
   }
}
