package me.nothing.smpcore.systems.smpcorelib.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class MenuConfig {
   private final String title;
   private final LayoutGrid layout;
   private final Map<Character, ItemSpec> bySymbol = new HashMap();
   private final Map<String, ItemSpec> byAction = new HashMap();
   private final char fillerSymbol;

   private MenuConfig(String var1, LayoutGrid var2, char var3) {
      this.title = var1;
      this.layout = var2;
      this.fillerSymbol = var3;
   }

   public static MenuConfig load(ConfigurationSection var0, String var1, Logger var2) {
      String str = var0.getString("menu.title", "Menu");
      String str2 = var0.getString("menu.filler-symbol", "-");
      char c = str2 != null && !str2.isEmpty() ? str2.charAt(0) : 45;
      Object obj = var0.getStringList(var1);
      if (((List)obj).isEmpty()) {
         String str3 = var0.getString(var1, "");
         obj = new ArrayList();
         if (!str3.isEmpty()) {
            ((List)obj).add(str3);
         }
      }

      MenuConfig menuConfig = new MenuConfig(str, LayoutGrid.parse((List)obj, c), c);
      ConfigurationSection configurationSection = var0.getConfigurationSection("items");
      if (configurationSection != null) {
         for(String var10 : configurationSection.getKeys(false)) {
            ConfigurationSection configurationSection2 = configurationSection.getConfigurationSection(var10);
            if (configurationSection2 != null) {
               ItemSpec itemSpec = ItemSpec.from(configurationSection2, var10, var2);
               if (itemSpec.symbol() != 0) {
                  menuConfig.bySymbol.put(itemSpec.symbol(), itemSpec);
               }

               menuConfig.byAction.put(itemSpec.action(), itemSpec);
            }
         }
      }

      return menuConfig;
   }

   public String title() {
      return this.title;
   }

   public LayoutGrid layout() {
      return this.layout;
   }

   public int rows() {
      return this.layout.rows();
   }

   public ItemSpec item(String var1) {
      return (ItemSpec)this.byAction.get(var1);
   }

   public List<Integer> slotsOfAction(String var1) {
      ItemSpec itemSpec = (ItemSpec)this.byAction.get(var1);
      return itemSpec == null ? List.of() : this.layout.slotsOf(itemSpec.symbol());
   }

   public void paging(Inventory var1, int var2) {
      this.paging(var1, -1, var2);
   }

   public void paging(Inventory var1, int var2, int var3) {
      if (var3 <= 1 || var2 >= 0 && var2 <= 0) {
         this.fill(var1, "previous");
         this.fill(var1, "page_previous");
      }

      if (var3 <= 1 || var2 >= 0 && var2 >= var3 - 1) {
         this.fill(var1, "next");
         this.fill(var1, "page_next");
      }

   }

   public void fill(Inventory var1, String var2) {
      ItemSpec itemSpec = (ItemSpec)this.bySymbol.get(this.fillerSymbol);

      for(int var5 : this.slotsOfAction(var2)) {
         if (var5 >= 0 && var5 < var1.getSize()) {
            ItemStack itemStack = itemSpec == null ? null : itemSpec.build();
            var1.setItem(var5, itemStack != null && itemStack.getType().isAir() ? null : itemStack);
         }
      }

   }

   public String actionAt(int var1) {
      ItemSpec itemSpec = (ItemSpec)this.bySymbol.get(this.layout.symbolAt(var1));
      return itemSpec == null ? null : itemSpec.action();
   }

   public void render(Inventory var1, Map<String, String> var2, char... var3) {
      label32:
      for(int var4 = 0; var4 < var1.getSize(); ++var4) {
         char c = this.layout.symbolAt(var4);

         for(char var9 : var3) {
            if (c == var9) {
               continue label32;
            }
         }

         ItemSpec itemSpec = (ItemSpec)this.bySymbol.get(c);
         if (itemSpec == null) {
            var1.setItem(var4, (ItemStack)null);
         } else {
            ItemStack itemStack = itemSpec.build(var2);
            var1.setItem(var4, itemStack.getType().isAir() ? null : itemStack);
         }
      }

   }

   public char fillerSymbol() {
      return this.fillerSymbol;
   }
}
