package me.nothing.smpcore.systems.voucher;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public final class Draft {
   private static final Pattern ID = Pattern.compile("[a-z0-9_]{1,32}");
   private final String originalId;
   private String id;
   private String displayName;
   private String itemData;
   private String materialName;
   private final List<String> lore;
   private final List<String> commands;

   private Draft(String str, String str2, String str3, String str4, String str5, List<String> list, List<String> list2) {
      this.originalId = str;
      this.id = str2;
      this.displayName = str3;
      this.itemData = str4;
      this.materialName = str5;
      this.lore = list;
      this.commands = list2;
   }

   public static Draft blank() {
      return new Draft((String)null, "", "", (String)null, "PAPER", new ArrayList(), new ArrayList());
   }

   public static Draft of(VoucherPlugin voucherPlugin, VoucherDef voucherDef) {
      ConfigurationSection configurationSection = voucherPlugin.section(voucherDef.id());
      String str = configurationSection == null ? null : configurationSection.getString("item-data", (String)null);
      ArrayList arrayList = configurationSection == null ? new ArrayList() : new ArrayList(configurationSection.getStringList("lore"));
      ArrayList arrayList2 = configurationSection == null ? new ArrayList() : new ArrayList(configurationSection.getStringList("rewards.commands"));
      return new Draft(voucherDef.id(), voucherDef.id(), voucherDef.displayName(), str != null && !str.isEmpty() ? str : null, voucherDef.material().name(), arrayList, arrayList2);
   }

   public boolean creating() {
      return this.originalId == null;
   }

   public String originalId() {
      return this.originalId;
   }

   public String id() {
      return this.id;
   }

   public String displayName() {
      return this.displayName;
   }

   public String materialName() {
      return this.materialName;
   }

   public List<String> lore() {
      return this.lore;
   }

   public List<String> commands() {
      return this.commands;
   }

   public String commandLine(String str, String str2) {
      return this.commands.isEmpty() ? str : String.join(str2, this.commands);
   }

   public String loreLine(String str, String str2) {
      return this.lore.isEmpty() ? str : String.join(str2, this.lore);
   }

   public boolean id(String input) {
      String str = input == null ? "" : input.trim().toLowerCase(Locale.ROOT);
      if (!ID.matcher(str).matches()) {
         return false;
      } else {
         this.id = str;
         return true;
      }
   }

   public void displayName(String str) {
      this.displayName = str == null ? "" : str;
   }

   public boolean capture(VoucherTags voucherTags, ItemStack source) {
      if (source != null && !source.getType().isAir()) {
         ItemStack itemStack = voucherTags.clear(source.clone());
         itemStack.setAmount(1);
         String str = ItemCodec.encode(itemStack);
         if (str == null) {
            return false;
         } else {
            this.itemData = str;
            this.materialName = itemStack.getType().name();
            return true;
         }
      } else {
         return false;
      }
   }

   public void addCommand(String str) {
      if (str != null && !str.isBlank()) {
         this.commands.add(str.trim());
      }

   }

   public void clearCommands() {
      this.commands.clear();
   }

   public void lore(String str, String str2) {
      this.lore.clear();
      if (str != null && !str.isBlank()) {
         for(String var6 : str.split(Pattern.quote(str2))) {
            this.lore.add(var6.trim());
         }

      }
   }

   public boolean complete() {
      return ID.matcher(this.id).matches();
   }

   public void save(VoucherPlugin voucherPlugin) {
      YamlConfiguration yamlConfiguration = voucherPlugin.vouchersFile().yaml();
      if (this.originalId != null && !this.originalId.equals(this.id)) {
         voucherPlugin.rename(this.originalId, this.id);
      }

      String str = "vouchers." + this.id;
      if (!yamlConfiguration.isConfigurationSection(str)) {
         yamlConfiguration.createSection(str);
         yamlConfiguration.set(str + ".enabled", true);
         yamlConfiguration.set(str + ".permission", "");
         yamlConfiguration.set(str + ".max-per-player", -1);
         yamlConfiguration.set(str + ".cooldown", "");
         yamlConfiguration.set(str + ".lifetime", "");
         yamlConfiguration.set(str + ".item.material", "PAPER");
         yamlConfiguration.set(str + ".rewards.money", 0);
      }

      yamlConfiguration.set(str + ".display-name", this.displayName.isEmpty() ? this.id : this.displayName);
      yamlConfiguration.set(str + ".lore", this.lore);
      yamlConfiguration.set(str + ".rewards.commands", this.commands);
      if (this.itemData != null && !this.itemData.isEmpty()) {
         yamlConfiguration.set(str + ".item-data", this.itemData);
      }

      voucherPlugin.saveVouchers();
   }

   public String plainName() {
      return Text.strip(this.displayName);
   }
}
