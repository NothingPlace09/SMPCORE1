package me.nothing.smpcore.systems.chat;

import io.papermc.paper.event.player.AsyncChatEvent;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.utils.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

public class ChatListener implements Listener {
   private final SmpCoreChat plugin;
   private final ChatMessageProcessor messageProcessor;

   public ChatListener(SmpCoreChat plugin) {
      this.plugin = plugin;
      this.messageProcessor = new ChatMessageProcessor(plugin);
   }

   private boolean isChatOff(Player player) {
      try {
         ChatManager cm = this.plugin.getChatManager();
         if (cm != null && cm.isPersonalOff(player.getUniqueId())) {
            return true;
         }
      } catch (Throwable t) {
      }

      try {
         JavaPlugin javaPlugin = this.plugin.getCore();
         if (javaPlugin instanceof SmpCore core) {
            Module mod = core.modules().get("settings");
            if (mod instanceof SettingsModule sm) {
               if (sm.isChatOff(player.getUniqueId())) {
                  return true;
               }
            }
         }
      } catch (Throwable t) {
      }

      return false;
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onChatEarly(AsyncChatEvent event) {
      Player player = event.getPlayer();
      ChatManager cm = this.plugin.getChatManager();
      if (cm != null && cm.isChatDisabled() && !player.hasPermission("smpcore.system.chat.bypass") && !player.hasPermission("smpcore.system.chat.manage")) {
         event.setCancelled(true);
         player.sendMessage(MessageUtil.colorComponent(this.plugin.getConfigManager().getMessage("chat.disabled")));
         return;
      }

      if (this.isChatOff(player)) {
         event.setCancelled(true);
         TextUtil.send(player, "&#fc0404You have general chat disabled. &7Use &#00a3fb/chattoggle&7 or /settings.");
      } else {
         event.viewers().removeIf((audience) -> {
            if (audience instanceof Player viewer) {
               return this.isChatOff(viewer);
            } else {
               return false;
            }
         });
      }
   }

   @EventHandler
   public void onChat(AsyncChatEvent event) {
      if (event.isCancelled() || !this.plugin.getConfigManager().isModuleEnabled("chat-format")) {
         return;
      }

      try {
         Player player = event.getPlayer();
         String rawMessage = PlainTextComponentSerializer.plainText().serialize(event.message());
         Component messageComponent = this.messageProcessor.processMessage(player, rawMessage);
         String format = this.plugin.getConfig().getString("chat-format.format", "%player%: %message%");
         format = PlaceholderUtil.replace(player, format);
         format = format.replace("%player%", player.getName());
         boolean hover = this.plugin.getConfigManager().isModuleEnabled("hover-chat");
         int msgIndex = format.indexOf("%message%");
         Component full;
         if (msgIndex == -1) {
            Component prefixComp = ColorUtil.colorComponent(format);
            if (hover) {
               prefixComp = HoverManager.applyHover(player, prefixComp);
            }

            full = prefixComp.append(messageComponent);
         } else {
            String prefix = format.substring(0, msgIndex);
            String suffix = format.substring(msgIndex + "%message%".length());
            Component prefixComp = ColorUtil.colorComponent(prefix);
            Component suffixComp = ColorUtil.colorComponent(suffix);
            // Il messaggio eredita il colore con cui finisce il prefisso (es. "&7" prima di %message%), ma resta un
            // componente: hover di [hand]/[inv], menzioni e colori del giocatore non vengono piu' appiattiti in testo.
            TextColor carry = lastColor(prefixComp, null);
            Component msgColored = carry == null ? messageComponent : Component.empty().color(carry).append(messageComponent);
            if (hover) {
               prefixComp = HoverManager.applyHover(player, prefixComp);
            }

            full = Component.empty().append(prefixComp).append(msgColored).append(suffixComp);
         }

         final Component rendered = full;
         event.renderer((source, sourceDisplayName, originalMessage, viewer) -> rendered);
      } catch (Throwable t) {
         this.plugin.getLogger().warning("[chat] could not format message of " + event.getPlayer().getName() + ": " + t.getClass().getSimpleName() + " " + t.getMessage());
      }
   }

   /** Colore effettivo dell'ultimo pezzo di testo visibile di un componente (null se non ha colore). */
   private static TextColor lastColor(Component c, TextColor inherited) {
      TextColor[] last = new TextColor[1];
      walk(c, inherited, last);
      return last[0];
   }

   private static void walk(Component c, TextColor inherited, TextColor[] last) {
      TextColor own = c.color() != null ? c.color() : inherited;
      if (c instanceof TextComponent tc && !tc.content().isEmpty()) {
         last[0] = own;
      }

      for(Component child : c.children()) {
         walk(child, own, last);
      }
   }
}
