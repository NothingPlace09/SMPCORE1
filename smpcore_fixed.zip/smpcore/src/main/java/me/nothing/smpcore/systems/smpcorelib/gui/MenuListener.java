package me.nothing.smpcore.systems.smpcorelib.gui;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.systems.smpcorelib.sound.Sounds;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class MenuListener implements Listener {
   private static final Map<String, Sounds> SOUNDS = new ConcurrentHashMap();
   private final Plugin plugin;

   public MenuListener(Plugin plugin) {
      if (plugin == null) {
         throw new IllegalArgumentException("MenuListener needs the plugin whose menus it serves");
      } else {
         this.plugin = plugin;
      }
   }

   public static void useSounds(Plugin plugin, Sounds sounds) {
      if (plugin != null) {
         if (sounds == null) {
            SOUNDS.remove(plugin.getName());
         } else {
            SOUNDS.put(plugin.getName(), sounds);
         }

      }
   }

   private Menu ours(InventoryHolder inventoryHolder) {
      if (inventoryHolder instanceof Menu found && found.isOwnedBy(this.plugin)) {
         return found;
      }

      return null;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = false
   )
   public void onClick(InventoryClickEvent inventoryClickEvent) {
      Menu menu = this.ours(inventoryClickEvent.getView().getTopInventory().getHolder());
      if (menu != null) {
         this.playClick(inventoryClickEvent);
         menu.handleClick(inventoryClickEvent);
      }

   }

   private void playClick(InventoryClickEvent inventoryClickEvent) {
      Sounds sounds = (Sounds)SOUNDS.get(this.plugin.getName());
      if (sounds != null) {
         HumanEntity humanEntity = inventoryClickEvent.getWhoClicked();
         if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            int i = inventoryClickEvent.getView().getTopInventory().getSize();
            if (inventoryClickEvent.getRawSlot() >= 0 && inventoryClickEvent.getRawSlot() < i) {
               ItemStack itemStack = inventoryClickEvent.getCurrentItem();
               if (itemStack != null && !itemStack.getType().isAir()) {
                  sounds.play(player, "click");
               }

               return;
            }

            return;
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onDrag(InventoryDragEvent inventoryDragEvent) {
      Menu menu = this.ours(inventoryDragEvent.getView().getTopInventory().getHolder());
      if (menu != null) {
         if (!menu.cancelByDefault()) {
            int i = inventoryDragEvent.getView().getTopInventory().getSize();

            for(int var5 : inventoryDragEvent.getRawSlots()) {
               if (var5 < i) {
                  inventoryDragEvent.setCancelled(true);
                  return;
               }
            }

         } else {
            inventoryDragEvent.setCancelled(true);
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = false
   )
   public void onClickFinal(InventoryClickEvent inventoryClickEvent) {
      Menu menu = this.ours(inventoryClickEvent.getView().getTopInventory().getHolder());
      if (menu != null && menu.cancelByDefault() && !inventoryClickEvent.isCancelled()) {
         inventoryClickEvent.setCancelled(true);
      }

   }

   @EventHandler
   public void onClose(InventoryCloseEvent inventoryCloseEvent) {
      Menu menu = this.ours(inventoryCloseEvent.getView().getTopInventory().getHolder());
      if (menu != null) {
         menu.handleClose(inventoryCloseEvent);
      }

   }
}
