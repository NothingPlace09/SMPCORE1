package me.nothing.smpcore.systems.invest;

import java.util.HashMap;
import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.config.ConfigFile;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuListener;
import me.nothing.smpcore.systems.smpcorelib.gui.Menus;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import me.nothing.smpcore.systems.smpcorelib.sound.Sounds;
import me.nothing.smpcore.systems.smpcorelib.storage.Storage;
import me.nothing.smpcore.systems.smpcorelib.storage.StorageFactory;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class InvestPlugin extends InvestBase implements Listener {
   private Storage storage;
   private InvestStore store;
   private ChatPrompt prompt;
   private Sounds sounds;
   private ConfigFile investMenuFile;
   private ConfigFile confirmInvestFile;
   private ConfigFile confirmDeleteFile;
   private MenuConfig investMenu;
   private MenuConfig confirmInvestMenu;
   private MenuConfig confirmDeleteMenu;
   private double per;
   private double perAdd;
   private int intervalSeconds;
   private double minInvest;
   private double maxInvest;
   private double refundPercent;
   private boolean ranksEnabled;
   private boolean autoCollectNeedsPermission;
   private Scheduler.Task incomeTask;
   private Scheduler.Task saveTask;

   protected void start() {
      this.investMenuFile = (new ConfigFile(this, "menu-invest.yml")).load(true);
      this.confirmInvestFile = (new ConfigFile(this, "menu-confirm-invest.yml")).load(true);
      this.confirmDeleteFile = (new ConfigFile(this, "menu-confirm-delete.yml")).load(true);
      this.storage = StorageFactory.baue(this, this.config().yaml().getConfigurationSection("storage"));
      this.store = new InvestStore(this.storage);
      this.applySettings();
      this.prompt = new ChatPrompt(this);
      this.configurePrompt();
      this.getServer().getPluginManager().registerEvents(this.prompt, this.core());
      this.getServer().getPluginManager().registerEvents(this, this.core());
      MenuListener.useSounds(this, this.sounds);
      this.getServer().getPluginManager().registerEvents(new MenuListener(this), this.core());
      for(Player var3 : Bukkit.getOnlinePlayers()) {
         this.store.get(var3.getUniqueId());
      }

      this.startTimers();
      if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         InvestPlaceholders.register(this);
      }

      this.getLogger().info("Invest ready" + (Scheduler.folia() ? " (Folia)" : "") + ".");
   }

   protected void stop() {
      try {
         InvestPlaceholders.dropActive();
      } catch (Throwable ignored) {
      }
      Menus.closeAll(this, (var0) -> var0 instanceof InvestMenu || var0 instanceof ConfirmMenu);
      this.stopTimers();
      if (this.store != null) {
         this.store.saveAll();
      }

      if (this.storage != null) {
         this.storage.close();
      }

   }

   private void applySettings() {
      YamlConfiguration yamlConfiguration = this.config().yaml();
      this.per = Math.max((double)1.0F, yamlConfiguration.getDouble("income.per", (double)100000.0F));
      this.perAdd = yamlConfiguration.getDouble("income.per-add", (double)1.0F);
      this.intervalSeconds = Math.max(1, yamlConfiguration.getInt("income.interval-seconds", 1));
      this.minInvest = Math.max((double)0.0F, yamlConfiguration.getDouble("limits.min-invest", (double)1000.0F));
      this.maxInvest = Math.max((double)0.0F, yamlConfiguration.getDouble("limits.max-invest", (double)1.0E10F));
      this.refundPercent = Math.min((double)100.0F, Math.max((double)0.0F, yamlConfiguration.getDouble("delete.refund-percent", (double)0.0F)));
      this.ranksEnabled = yamlConfiguration.getBoolean("ranks.enabled", true);
      this.autoCollectNeedsPermission = yamlConfiguration.getBoolean("auto-collect.permission-required", true);
      this.sounds = new Sounds(yamlConfiguration.getConfigurationSection("sounds"));
      this.investMenu = MenuConfig.load(this.investMenuFile.yaml(), "menu.layout", this.getLogger());
      this.confirmInvestMenu = MenuConfig.load(this.confirmInvestFile.yaml(), "menu.layout", this.getLogger());
      this.confirmDeleteMenu = MenuConfig.load(this.confirmDeleteFile.yaml(), "menu.layout", this.getLogger());
   }

   private void configurePrompt() {
      this.prompt.configure(this.config().yaml().getStringList("input.cancel-words"), this.config().yaml().getInt("input.timeout-seconds", 60));
   }

   public void reload() {
      Menus.closeAll(this, (var0) -> var0 instanceof InvestMenu || var0 instanceof ConfirmMenu);
      this.config().load(true);
      this.investMenuFile.load(true);
      this.confirmInvestFile.load(true);
      this.confirmDeleteFile.load(true);
      this.applySettings();
      this.configurePrompt();
      MenuListener.useSounds(this, this.sounds);
      this.startTimers();
   }

   private void startTimers() {
      this.stopTimers();
      long l = (long)this.intervalSeconds * 20L;
      this.incomeTask = Scheduler.timer(this, this::tick, l, l);
      long l2 = (long)Math.max(30, this.config().yaml().getInt("data.save-interval-seconds", 300)) * 20L;
      this.saveTask = Scheduler.timer(this, () -> this.store.saveAll(), l2, l2);
   }

   private void stopTimers() {
      for(Scheduler.Task var4 : new Scheduler.Task[]{this.incomeTask, this.saveTask}) {
         if (var4 != null) {
            var4.cancel();
         }
      }

      this.incomeTask = null;
      this.saveTask = null;
   }

   private void tick() {
      for(Player var2 : Bukkit.getOnlinePlayers()) {
         Scheduler.atEntity(this, var2, () -> this.award(var2));
      }

   }

   private void award(Player player) {
      InvestData investData = this.store.get(player.getUniqueId());
      if (!(investData.invested() <= (double)0.0F)) {
         double d = this.income(player, investData);
         if (!(d <= (double)0.0F)) {
            if (investData.autoCollect() && this.mayAutoCollect(player)) {
               if (this.economy().deposit(player, d)) {
                  this.notifyIncome(player, d);
               }

            } else {
               investData.addPending(d);
            }
         }
      }
   }

   public double income(Player player, InvestData investData) {
      return this.incomeFor(player, investData.invested());
   }

   public double incomeFor(Player player, double d) {
      return Math.max((double)0.0F, d) / this.per * this.perAddOf(player);
   }

   public double income(Player player) {
      return this.income(player, this.store.get(player.getUniqueId()));
   }

   private double perAddOf(Player player) {
      return this.best(player, "per-add", this.perAdd);
   }

   public double maxInvest(Player player) {
      return this.best(player, "max-invest", this.maxInvest) + this.store.get(player.getUniqueId()).extraMax();
   }

   private double best(Player player, String str, double base) {
      if (!this.ranksEnabled) {
         return base;
      } else {
         ConfigurationSection configurationSection = this.config().yaml().getConfigurationSection("ranks");
         if (configurationSection == null) {
            return base;
         } else {
            double d = base;

            for(String var9 : configurationSection.getKeys(false)) {
               ConfigurationSection configurationSection2 = configurationSection.getConfigurationSection(var9);
               if (configurationSection2 != null && player.hasPermission("smpcoreinvest.rank." + var9)) {
                  d = Math.max(d, configurationSection2.getDouble(str, d));
               }
            }

            return d;
         }
      }
   }

   private void notifyIncome(Player player, double d) {
      Map map = Map.of("amount", EconomyHook.format(d));
      YamlConfiguration yamlConfiguration = this.config().yaml();
      if (yamlConfiguration.getBoolean("notify.actionbar.enabled", true)) {
         Text.actionBar(player, Text.apply(yamlConfiguration.getString("notify.actionbar.text", ""), map));
      }

      if (yamlConfiguration.getBoolean("notify.chat.enabled", false)) {
         player.sendMessage(Text.chat(Text.apply(yamlConfiguration.getString("notify.chat.text", ""), map)));
      }

      if (yamlConfiguration.getBoolean("notify.title.enabled", false)) {
         player.sendTitle(Text.chat(Text.apply(yamlConfiguration.getString("notify.title.text", ""), map)), Text.chat(Text.apply(yamlConfiguration.getString("notify.title.subtitle", ""), map)), 0, 20, 10);
      }

   }

   public boolean invest(Player player, double d) {
      InvestData investData = this.store.get(player.getUniqueId());
      if (Double.isFinite(d) && !(d <= (double)0.0F)) {
         if (d < this.minInvest) {
            this.message(player, "below-minimum", Map.of("min", EconomyHook.format(this.minInvest)));
            this.sounds.play(player, "deny");
            return false;
         } else {
            double cap = this.maxInvest(player);
            if (investData.invested() + d > cap) {
               this.message(player, "above-maximum", Map.of("max", EconomyHook.format(cap)));
               this.sounds.play(player, "deny");
               return false;
            } else if (!this.economy().withdraw(player, d)) {
               this.message(player, "not-enough-money", Map.of("amount", EconomyHook.format(d)));
               this.sounds.play(player, "deny");
               return false;
            } else {
               investData.setInvested(investData.invested() + d);
               this.store.save(player.getUniqueId());
               this.message(player, "invested", Map.of("amount", EconomyHook.format(d), "income", EconomyHook.format(this.income(player, investData))));
               this.sounds.play(player, "success");
               return true;
            }
         }
      } else {
         this.message(player, "invalid-amount");
         this.sounds.play(player, "deny");
         return false;
      }
   }

   public void collect(Player player) {
      InvestData investData = this.store.get(player.getUniqueId());
      double d = investData.pending();
      if (d <= (double)0.0F) {
         this.message(player, "nothing-to-collect");
         this.sounds.play(player, "deny");
      } else if (this.economy().deposit(player, d)) {
         investData.setPending((double)0.0F);
         this.store.save(player.getUniqueId());
         this.message(player, "collected", Map.of("amount", EconomyHook.format(d)));
         this.sounds.play(player, "collect");
      }
   }

   public void delete(Player player) {
      InvestData investData = this.store.get(player.getUniqueId());
      if (investData.invested() <= (double)0.0F) {
         this.message(player, "nothing-to-delete");
         this.sounds.play(player, "deny");
      } else {
         double d = investData.invested() * this.refundPercent / (double)100.0F;
         investData.setInvested((double)0.0F);
         investData.setPending((double)0.0F);
         this.store.save(player.getUniqueId());
         if (d > (double)0.0F && this.economy().deposit(player, d)) {
            this.message(player, "deleted-refund", Map.of("amount", EconomyHook.format(d)));
         } else {
            this.message(player, "deleted");
         }

         this.sounds.play(player, "success");
      }
   }

   public void toggleAutoCollect(Player player) {
      if (!this.mayAutoCollect(player)) {
         this.message(player, "autocollect-denied");
         this.sounds.play(player, "deny");
      } else {
         InvestData investData = this.store.get(player.getUniqueId());
         investData.setAutoCollect(!investData.autoCollect());
         this.store.save(player.getUniqueId());
         this.message(player, investData.autoCollect() ? "autocollect-on" : "autocollect-off");
         this.sounds.play(player, "click");
      }
   }

   public boolean mayAutoCollect(Player player) {
      return !this.autoCollectNeedsPermission || player.hasPermission("smpcoreinvest.autocollect");
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent playerJoinEvent) {
      this.store.get(playerJoinEvent.getPlayer().getUniqueId());
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent playerQuitEvent) {
      this.prompt.forget(playerQuitEvent.getPlayer().getUniqueId());
      this.store.unload(playerQuitEvent.getPlayer().getUniqueId());
   }

   public InvestStore store() {
      return this.store;
   }

   public ChatPrompt prompt() {
      return this.prompt;
   }

   public Sounds sounds() {
      return this.sounds;
   }

   public MenuConfig investMenu() {
      return this.investMenu;
   }

   public MenuConfig confirmInvestMenu() {
      return this.confirmInvestMenu;
   }

   public MenuConfig confirmDeleteMenu() {
      return this.confirmDeleteMenu;
   }

   public ConfigFile investMenuFile() {
      return this.investMenuFile;
   }

   public ConfigFile confirmInvestFile() {
      return this.confirmInvestFile;
   }

   public ConfigFile confirmDeleteFile() {
      return this.confirmDeleteFile;
   }

   public double minInvest() {
      return this.minInvest;
   }

   public int intervalSeconds() {
      return this.intervalSeconds;
   }

   public double refundPercent() {
      return this.refundPercent;
   }

   public Map<String, String> values(Player player) {
      InvestData investData = this.store.get(player.getUniqueId());
      HashMap hashMap = new HashMap();
      hashMap.put("player", player.getName());
      hashMap.put("invested", EconomyHook.format(investData.invested()));
      hashMap.put("pending", EconomyHook.format(investData.pending()));
      hashMap.put("max", EconomyHook.format(this.maxInvest(player)));
      hashMap.put("min", EconomyHook.format(this.minInvest));
      hashMap.put("income", EconomyHook.format(this.income(player, investData)));
      hashMap.put("interval", String.valueOf(this.intervalSeconds));
      hashMap.put("balance", EconomyHook.format(this.economy().balance(player)));
      hashMap.put("room", EconomyHook.format(Math.max((double)0.0F, this.maxInvest(player) - investData.invested())));
      hashMap.put("refund", EconomyHook.format(investData.invested() * this.refundPercent / (double)100.0F));
      return hashMap;
   }

   public void say(CommandSender commandSender, String str) {
      this.message(commandSender, str);
   }

   public void say(CommandSender commandSender, String str, Map<String, String> map) {
      this.message(commandSender, str, map);
   }
}
