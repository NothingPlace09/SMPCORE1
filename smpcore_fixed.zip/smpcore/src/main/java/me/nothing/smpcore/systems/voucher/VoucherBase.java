package me.nothing.smpcore.systems.voucher;

import java.util.Map;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.SmpCoreHost;
import me.nothing.smpcore.systems.smpcorelib.config.ConfigFile;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public abstract class VoucherBase extends SmpCoreHost {
   protected VoucherBase() {
      super("voucher");
   }

   private static final String ACTIONBAR = "<actionbar>";
   private ConfigFile config;

   protected abstract void start() throws Exception;

   protected void stop() {
   }

   public final void onEnable() {
      this.config = (new ConfigFile(this, "settings.yml")).load(true);

      try {
         this.start();
      } catch (Exception e) {
         Logger logger = this.getLogger();
         String str = this.getName();
         logger.severe("Startup failed - check plugins/" + str + "/" + this.config.realPath());
         e.printStackTrace();
         this.disableSelf();
      }

   }

   public final void onDisable() {
      this.stop();
      super.onDisable();
   }

   protected ConfigFile config() {
      return this.config;
   }

   public void message(CommandSender commandSender, String key, Map<String, String> map) {
      String str = this.config.yaml().getString("messages." + key, "");
      if (str != null && !str.isEmpty()) {
         if (str.startsWith("<actionbar>")) {
            String str2 = str.substring("<actionbar>".length());
            if (commandSender instanceof Player) {
               Player player = (Player)commandSender;
               Text.actionBar(player, Text.apply(str2, map));
            } else {
               commandSender.sendMessage(Text.chat(Text.apply(str2, map)));
            }

         } else {
            String str2 = str.indexOf(10) >= 0 ? "" : this.config.yaml().getString("prefix", "");
            commandSender.sendMessage(Text.chat(Text.apply(str2 + str, map)));
         }
      }
   }

   public void message(CommandSender commandSender, String str) {
      this.message(commandSender, str, Map.of());
   }
}
