package me.nothing.smpcore.systems.tab;

import me.clip.placeholderapi.PlaceholderAPI;
import me.nothing.smpcore.economy.CoreEconomy;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;

/**
 * Placeholder usati da tab e scoreboard. I piu' comuni (Vault, Statistic, Server, Player) sono risolti
 * internamente, cosi' funzionano anche senza scaricare le espansioni PlaceholderAPI; il resto passa da PAPI.
 */
public final class TabPlaceholders {
   private TabPlaceholders() {
   }

   public static String apply(Player p, String text) {
      if (text == null) {
         return "";
      }

      String out = text;
      if (out.indexOf('%') >= 0) {
         out = out.replace("%player%", p.getName()).replace("%online%", String.valueOf(Bukkit.getOnlinePlayers().size())).replace("%world%", p.getWorld() != null ? p.getWorld().getName() : "").replace("%ping%", String.valueOf(p.getPing())).replace("%player_ping%", String.valueOf(p.getPing()));
         if (out.contains("%vault_")) {
            out = out.replace("%vault_eco_balance_formatted%", balance(p, true)).replace("%vault_eco_balance%", balance(p, false)).replace("%vault_suffix%", meta(p, false)).replace("%vault_prefix%", meta(p, true));
         }

         if (out.contains("%luckperms_")) {
            out = out.replace("%luckperms_prefix%", meta(p, true)).replace("%luckperms_suffix%", meta(p, false));
         }

         if (out.contains("%statistic_")) {
            out = out.replace("%statistic_player_kills%", stat(p, Statistic.PLAYER_KILLS)).replace("%statistic_deaths%", stat(p, Statistic.DEATHS)).replace("%statistic_time_played%", playtime(p));
         }
      }

      if (out.indexOf('%') >= 0) {
         try {
            if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
               out = PlaceholderAPI.setPlaceholders(p, out);
            }
         } catch (Throwable t) {
         }
      }

      return normalize(out);
   }

   /** Il testo resta com'e': &#RRGGBB, <#RRGGBB>, tag MiniMessage e <head:..> li risolvono Rich e TabHeads. */
   public static String normalize(String s) {
      if (s == null) {
         return "";
      }

      return s;
   }

   private static String balance(Player p, boolean formatted) {
      try {
         double bal = CoreEconomy.balanceOf(p);
         return formatted ? CoreEconomy.formatMoney(bal) : String.valueOf((long)bal);
      } catch (Throwable t) {
         return "0";
      }
   }

   private static String stat(Player p, Statistic statistic) {
      try {
         return String.valueOf(p.getStatistic(statistic));
      } catch (Throwable t) {
         return "0";
      }
   }

   private static String playtime(Player p) {
      try {
         long minutes = (long)(p.getStatistic(Statistic.PLAY_ONE_MINUTE) / 20 / 60);
         return minutes / 60L + "h " + minutes % 60L + "m";
      } catch (Throwable t) {
         return "0h 0m";
      }
   }

   public static String meta(Player p, boolean prefix) {
      try {
         if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            return "";
         }

         User user = LuckPermsProvider.get().getUserManager().getUser(p.getUniqueId());
         if (user == null) {
            return "";
         }

         String value = prefix ? user.getCachedData().getMetaData().getPrefix() : user.getCachedData().getMetaData().getSuffix();
         return value != null ? value : "";
      } catch (Throwable t) {
         return "";
      }
   }
}
